import { db } from "@db";
import { users, loans, payments, capitalShares, officers, newsFeed, funds, monthlyIncome, monthlyExpenses, notifications, memberSavings, dividendRecords, chatMessages } from "@shared/schema";
import type { 
  User, InsertUser, Loan, InsertLoan, Payment, InsertPayment, 
  CapitalShare, InsertCapitalShare, Officer, InsertOfficer,
  NewsFeed, InsertNewsFeed, Fund, MonthlyIncome, InsertMonthlyIncome,
  MonthlyExpense, InsertMonthlyExpense, Notification, InsertNotification,
  MemberSavings, InsertMemberSavings, DividendRecord, InsertDividendRecord,
  ChatMessage, InsertChatMessage
} from "@shared/schema";
import { eq, and, desc, sql, asc } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "@db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(userData: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getActiveMembers(): Promise<User[]>;
  getInactiveMembers(): Promise<User[]>;
  getAllMembers(): Promise<User[]>;
  
  // Capital Share operations
  getCapitalShare(userId: number): Promise<CapitalShare | undefined>;
  addCapitalShare(capitalShareData: InsertCapitalShare): Promise<CapitalShare>;
  updateCapitalShare(id: number, amount: number): Promise<CapitalShare | undefined>;
  
  // Loan operations
  getLoan(id: number): Promise<Loan | undefined>;
  getLoansByUser(userId: number): Promise<Loan[]>;
  getActiveLoansByUser(userId: number): Promise<Loan[]>;
  createLoan(loanData: InsertLoan): Promise<Loan>;
  updateLoan(id: number, loanData: Partial<Loan>): Promise<Loan | undefined>;
  getAllActiveLoans(): Promise<Loan[]>;
  getAllLoans(): Promise<Loan[]>;
  
  // Payment operations
  getPayment(id: number): Promise<Payment | undefined>;
  getPaymentsByLoan(loanId: number): Promise<Payment[]>;
  createPayment(paymentData: InsertPayment): Promise<Payment>;
  
  // Officer operations
  getOfficers(): Promise<Officer[]>;
  assignOfficer(officerData: InsertOfficer): Promise<Officer>;
  removeOfficer(id: number): Promise<boolean>;
  
  // Fund operations
  getFunds(): Promise<Fund | undefined>;
  updateFunds(fundsData: Partial<Fund>): Promise<Fund | undefined>;
  
  // News Feed operations
  getNewsFeed(id: number): Promise<NewsFeed | undefined>;
  getAllNews(): Promise<NewsFeed[]>;
  createNews(newsData: InsertNewsFeed): Promise<NewsFeed>;
  updateNews(id: number, newsData: Partial<NewsFeed>): Promise<NewsFeed | undefined>;
  deleteNews(id: number): Promise<boolean>;
  
  // Monthly Income operations
  getMonthlyIncome(id: number): Promise<MonthlyIncome | undefined>;
  getMonthlyIncomeByDate(year: number, month: number): Promise<MonthlyIncome[]>;
  createMonthlyIncome(incomeData: InsertMonthlyIncome): Promise<MonthlyIncome>;
  updateMonthlyIncome(id: number, incomeData: Partial<MonthlyIncome>): Promise<MonthlyIncome | undefined>;
  deleteMonthlyIncome(id: number): Promise<boolean>;
  
  // Monthly Expense operations
  getMonthlyExpense(id: number): Promise<MonthlyExpense | undefined>;
  getMonthlyExpensesByDate(year: number, month: number): Promise<MonthlyExpense[]>;
  createMonthlyExpense(expenseData: InsertMonthlyExpense): Promise<MonthlyExpense>;
  updateMonthlyExpense(id: number, expenseData: Partial<MonthlyExpense>): Promise<MonthlyExpense | undefined>;
  deleteMonthlyExpense(id: number): Promise<boolean>;
  
  // Notification operations
  getNotificationsForUser(userId: number): Promise<Notification[]>;
  getUnreadNotificationsForUser(userId: number): Promise<Notification[]>;
  createNotification(notificationData: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: number): Promise<boolean>;
  markAllNotificationsAsRead(userId: number): Promise<boolean>;
  
  // Chat message operations
  getChatMessages(limit?: number): Promise<ChatMessage[]>;
  createChatMessage(messageData: InsertChatMessage): Promise<ChatMessage>;
  
  // Session store
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    try {
      console.log("Initializing PostgreSQL session store...");
      this.sessionStore = new PostgresSessionStore({ 
        pool, 
        tableName: 'session',
        createTableIfMissing: true 
      });
      console.log("PostgreSQL session store initialized successfully.");
    } catch (error) {
      console.error("Error initializing PostgreSQL session store:", error);
      // Create a backup in-memory session store
      const MemoryStore = require('memorystore')(session);
      this.sessionStore = new MemoryStore({});
      console.log("Fallback to memory session store.");
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return result[0];
  }

  async createUser(userData: InsertUser): Promise<User> {
    // Check if the email is the special admin email
    if (userData.email === "sebuguerojanmark@gmail.com") {
      userData.role = "admin";
    }
    
    const result = await db.insert(users).values(userData).returning();
    return result[0];
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const result = await db.update(users)
      .set({ ...userData, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  async getActiveMembers(): Promise<User[]> {
    return await db.select().from(users)
      .where(and(eq(users.role, "member"), eq(users.status, "active")))
      .orderBy(asc(users.name));
  }

  async getInactiveMembers(): Promise<User[]> {
    return await db.select().from(users)
      .where(and(eq(users.role, "member"), eq(users.status, "inactive")))
      .orderBy(asc(users.name));
  }

  async getAllMembers(): Promise<User[]> {
    return await db.select().from(users)
      .where(eq(users.role, "member"))
      .orderBy(asc(users.name));
  }

  async deleteUser(id: number): Promise<boolean> {
    // First check if the user has any active loans
    const activeLoans = await this.getActiveLoansByUser(id);
    if (activeLoans && activeLoans.length > 0) {
      throw new Error("Cannot delete member with active loans");
    }
    
    // Delete user
    const result = await db.delete(users).where(eq(users.id, id)).returning();
    return result.length > 0;
  }

  // Capital Share operations
  async getCapitalShare(userId: number): Promise<CapitalShare | undefined> {
    const result = await db.select().from(capitalShares).where(eq(capitalShares.userId, userId)).limit(1);
    return result[0];
  }

  async addCapitalShare(capitalShareData: InsertCapitalShare): Promise<CapitalShare> {
    const result = await db.insert(capitalShares).values(capitalShareData).returning();
    return result[0];
  }

  async updateCapitalShare(id: number, amount: number): Promise<CapitalShare | undefined> {
    const result = await db.update(capitalShares)
      .set({ amount, updatedAt: new Date() })
      .where(eq(capitalShares.id, id))
      .returning();
    return result[0];
  }

  // Loan operations
  async getLoan(id: number): Promise<Loan | undefined> {
    const result = await db.select().from(loans).where(eq(loans.id, id)).limit(1);
    return result[0];
  }

  async getLoansByUser(userId: number): Promise<Loan[]> {
    return await db.select().from(loans)
      .where(eq(loans.userId, userId))
      .orderBy(desc(loans.createdAt));
  }

  async getActiveLoansByUser(userId: number): Promise<Loan[]> {
    return await db.select().from(loans)
      .where(and(eq(loans.userId, userId), eq(loans.status, "active")))
      .orderBy(desc(loans.createdAt));
  }

  async createLoan(loanData: InsertLoan): Promise<Loan> {
    const result = await db.insert(loans).values(loanData).returning();
    return result[0];
  }

  async updateLoan(id: number, loanData: Partial<Loan>): Promise<Loan | undefined> {
    const result = await db.update(loans)
      .set({ ...loanData, updatedAt: new Date() })
      .where(eq(loans.id, id))
      .returning();
    return result[0];
  }

  async getAllActiveLoans(): Promise<Loan[]> {
    return await db.select().from(loans)
      .where(eq(loans.status, "active"))
      .orderBy(desc(loans.createdAt));
  }

  async getAllLoans(): Promise<Loan[]> {
    return await db.select().from(loans)
      .orderBy(desc(loans.createdAt));
  }

  // Payment operations
  async getPayment(id: number): Promise<Payment | undefined> {
    const result = await db.select().from(payments).where(eq(payments.id, id)).limit(1);
    return result[0];
  }

  async getPaymentsByLoan(loanId: number): Promise<Payment[]> {
    return await db.select().from(payments)
      .where(eq(payments.loanId, loanId))
      .orderBy(desc(payments.datePaid));
  }

  async createPayment(paymentData: InsertPayment): Promise<Payment> {
    const result = await db.insert(payments).values({
      ...paymentData,
      status: 'pending',
      paymentMethod: paymentData.paymentMethod || 'counter'
    }).returning();
    return result[0];
  }
  
  async verifyPayment(paymentId: number, adminId: number, paymentNote?: string): Promise<Payment | undefined> {
    const result = await db.update(payments)
      .set({
        status: 'verified',
        verifiedBy: adminId,
        verifiedAt: new Date(),
        paymentNote: paymentNote
      })
      .where(eq(payments.id, paymentId))
      .returning();
    return result[0];
  }
  
  async getPendingPayments(): Promise<Payment[]> {
    return await db.select().from(payments)
      .where(eq(payments.status, 'pending'))
      .orderBy(desc(payments.datePaid));
  }

  // Officer operations
  async getOfficers(): Promise<Officer[]> {
    return await db.select().from(officers)
      .orderBy(asc(officers.position));
  }

  async assignOfficer(officerData: InsertOfficer): Promise<Officer> {
    const result = await db.insert(officers).values(officerData).returning();
    return result[0];
  }

  async removeOfficer(id: number): Promise<boolean> {
    const result = await db.delete(officers).where(eq(officers.id, id)).returning();
    return result.length > 0;
  }

  // Fund operations
  async getFunds(): Promise<Fund | undefined> {
    const result = await db.select().from(funds).limit(1);
    return result[0];
  }

  async updateFunds(fundsData: Partial<Fund>): Promise<Fund | undefined> {
    const existingFunds = await this.getFunds();
    
    if (existingFunds) {
      const result = await db.update(funds)
        .set({ ...fundsData, updatedAt: new Date() })
        .where(eq(funds.id, existingFunds.id))
        .returning();
      return result[0];
    } else {
      const result = await db.insert(funds).values({
        onhandCash: fundsData.onhandCash || 0,
        capitalFund: fundsData.capitalFund || 0,
        reserveFund: fundsData.reserveFund || 0,
        updatedAt: new Date()
      }).returning();
      return result[0];
    }
  }

  // News Feed operations
  async getNewsFeed(id: number): Promise<NewsFeed | undefined> {
    const result = await db.select().from(newsFeed).where(eq(newsFeed.id, id)).limit(1);
    return result[0];
  }

  async getAllNews(): Promise<NewsFeed[]> {
    return await db.select().from(newsFeed)
      .orderBy(desc(newsFeed.createdAt));
  }

  async createNews(newsData: InsertNewsFeed): Promise<NewsFeed> {
    const result = await db.insert(newsFeed).values(newsData).returning();
    return result[0];
  }

  async updateNews(id: number, newsData: Partial<NewsFeed>): Promise<NewsFeed | undefined> {
    const result = await db.update(newsFeed)
      .set(newsData)
      .where(eq(newsFeed.id, id))
      .returning();
    return result[0];
  }

  async deleteNews(id: number): Promise<boolean> {
    const result = await db.delete(newsFeed).where(eq(newsFeed.id, id)).returning();
    return result.length > 0;
  }

  // Monthly Income operations
  async getMonthlyIncome(id: number): Promise<MonthlyIncome | undefined> {
    const result = await db.select().from(monthlyIncome).where(eq(monthlyIncome.id, id)).limit(1);
    return result[0];
  }

  async getMonthlyIncomeByDate(year: number, month: number): Promise<MonthlyIncome[]> {
    // PostgreSQL date formatting to extract year and month
    return await db.select().from(monthlyIncome)
      .where(
        and(
          sql`EXTRACT(YEAR FROM ${monthlyIncome.date}) = ${year}`,
          sql`EXTRACT(MONTH FROM ${monthlyIncome.date}) = ${month}`
        )
      )
      .orderBy(desc(monthlyIncome.date));
  }

  async createMonthlyIncome(incomeData: InsertMonthlyIncome): Promise<MonthlyIncome> {
    const result = await db.insert(monthlyIncome).values(incomeData).returning();
    return result[0];
  }

  async updateMonthlyIncome(id: number, incomeData: Partial<MonthlyIncome>): Promise<MonthlyIncome | undefined> {
    const result = await db.update(monthlyIncome)
      .set(incomeData)
      .where(eq(monthlyIncome.id, id))
      .returning();
    return result[0];
  }

  async deleteMonthlyIncome(id: number): Promise<boolean> {
    const result = await db.delete(monthlyIncome).where(eq(monthlyIncome.id, id)).returning();
    return result.length > 0;
  }

  // Monthly Expense operations
  async getMonthlyExpense(id: number): Promise<MonthlyExpense | undefined> {
    const result = await db.select().from(monthlyExpenses).where(eq(monthlyExpenses.id, id)).limit(1);
    return result[0];
  }

  async getMonthlyExpensesByDate(year: number, month: number): Promise<MonthlyExpense[]> {
    // PostgreSQL date formatting to extract year and month
    return await db.select().from(monthlyExpenses)
      .where(
        and(
          sql`EXTRACT(YEAR FROM ${monthlyExpenses.date}) = ${year}`,
          sql`EXTRACT(MONTH FROM ${monthlyExpenses.date}) = ${month}`
        )
      )
      .orderBy(desc(monthlyExpenses.date));
  }

  async createMonthlyExpense(expenseData: InsertMonthlyExpense): Promise<MonthlyExpense> {
    const result = await db.insert(monthlyExpenses).values(expenseData).returning();
    return result[0];
  }

  async updateMonthlyExpense(id: number, expenseData: Partial<MonthlyExpense>): Promise<MonthlyExpense | undefined> {
    const result = await db.update(monthlyExpenses)
      .set(expenseData)
      .where(eq(monthlyExpenses.id, id))
      .returning();
    return result[0];
  }

  async deleteMonthlyExpense(id: number): Promise<boolean> {
    const result = await db.delete(monthlyExpenses).where(eq(monthlyExpenses.id, id)).returning();
    return result.length > 0;
  }
  
  // Savings operations
  async getMemberSavings(userId: number): Promise<any[]> {
    return await db.select().from(memberSavings)
      .where(eq(memberSavings.userId, userId))
      .orderBy(desc(memberSavings.date));
  }
  
  async getMemberSavingsBalance(userId: number): Promise<number> {
    const latestSavings = await db.select()
      .from(memberSavings)
      .where(eq(memberSavings.userId, userId))
      .orderBy(desc(memberSavings.date))
      .limit(1);
    
    if (latestSavings.length > 0) {
      return latestSavings[0].balance;
    }
    return 0;
  }
  
  async createSavingsTransaction(savingsData: any): Promise<any> {
    // Get current balance
    const currentBalance = await this.getMemberSavingsBalance(savingsData.userId);
    
    // Calculate new balance based on transaction type
    let newBalance = currentBalance;
    if (savingsData.transactionType === 'deposit' || savingsData.transactionType === 'dividend') {
      newBalance += savingsData.amount;
    } else if (savingsData.transactionType === 'withdrawal') {
      newBalance -= savingsData.amount;
      if (newBalance < 0) throw new Error('Insufficient savings balance');
    }
    
    // Create transaction with updated balance
    const result = await db.insert(memberSavings).values({
      ...savingsData,
      balance: newBalance,
      date: new Date()
    }).returning();
    
    return result[0];
  }
  
  // Dividend operations
  async createDividendRecord(dividendData: any): Promise<any> {
    const result = await db.insert(dividendRecords).values({
      ...dividendData,
      distributionDate: new Date()
    }).returning();
    
    return result[0];
  }
  
  async getDividendRecords(): Promise<any[]> {
    return await db.select().from(dividendRecords)
      .orderBy(desc(dividendRecords.distributionDate));
  }
  
  async distributeDividends(dividendId: number, adminId: number): Promise<boolean> {
    const dividend = await db.select().from(dividendRecords)
      .where(eq(dividendRecords.id, dividendId))
      .limit(1);
    
    if (!dividend.length || dividend[0].status !== 'pending') {
      return false;
    }
    
    // Get all active members
    const members = await this.getActiveMembers();
    
    // Distribute to each member's savings
    const dividendPerMember = dividend[0].totalAmount / members.length;
    
    for (const member of members) {
      await this.createSavingsTransaction({
        userId: member.id,
        amount: dividendPerMember,
        transactionType: 'dividend',
        note: `Annual dividend for ${dividend[0].year}`,
        processedBy: adminId
      });
      
      // Create notification for member
      await this.createNotification({
        userId: member.id,
        title: 'Dividend Received',
        message: `You have received ₱${dividendPerMember.toFixed(2)} as annual dividend for ${dividend[0].year}.`,
        type: 'dividend',
        relatedId: dividendId
      });
    }
    
    // Update dividend status
    await db.update(dividendRecords)
      .set({ status: 'completed' })
      .where(eq(dividendRecords.id, dividendId));
    
    return true;
  }
  
  // Notification operations
  async getNotificationsForUser(userId: number): Promise<Notification[]> {
    return await db.select().from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }
  
  async getUnreadNotificationsForUser(userId: number): Promise<Notification[]> {
    return await db.select().from(notifications)
      .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)))
      .orderBy(desc(notifications.createdAt));
  }
  
  async createNotification(notificationData: InsertNotification): Promise<Notification> {
    const result = await db.insert(notifications).values(notificationData).returning();
    return result[0];
  }
  
  async markNotificationAsRead(id: number): Promise<boolean> {
    const result = await db.update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id))
      .returning();
    return result.length > 0;
  }
  
  async markAllNotificationsAsRead(userId: number): Promise<boolean> {
    const result = await db.update(notifications)
      .set({ isRead: true })
      .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)))
      .returning();
    return result.length > 0;
  }

  // Chat message operations
  async getChatMessages(limit: number = 100): Promise<ChatMessage[]> {
    try {
      return await db.select()
        .from(chatMessages)
        .orderBy(desc(chatMessages.createdAt))
        .limit(limit);
    } catch (error) {
      console.error("Error fetching chat messages:", error);
      return [];
    }
  }

  async createChatMessage(messageData: InsertChatMessage): Promise<ChatMessage> {
    const result = await db.insert(chatMessages).values(messageData).returning();
    return result[0];
  }
}

// Create a storage instance
export const storage = new DatabaseStorage();
