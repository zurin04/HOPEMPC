#!/bin/bash

# HOPEMPC VPS Deployment Script
# This script sets up the HOPEMPC Cooperative Management System on a VPS

echo "======================================"
echo "HOPEMPC VPS Deployment Script"
echo "======================================"

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   echo "This script should not be run as root for security reasons."
   echo "Please run as a regular user with sudo privileges."
   exit 1
fi

# Update system packages
echo "Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install Node.js 20.x
echo "Installing Node.js 20.x..."
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install PostgreSQL
echo "Installing PostgreSQL..."
sudo apt install -y postgresql postgresql-contrib

# Install Nginx
echo "Installing Nginx..."
sudo apt install -y nginx

# Install PM2 for process management
echo "Installing PM2..."
sudo npm install -g pm2

# Create application directory
APP_DIR="/var/www/hopempc"
echo "Creating application directory at $APP_DIR..."
sudo mkdir -p $APP_DIR
sudo chown $USER:$USER $APP_DIR

# Copy current application files
echo "Setting up application..."
cp -r . $APP_DIR/
cd $APP_DIR

# Install dependencies
echo "Installing application dependencies..."
npm install

# Set up PostgreSQL database
echo "Setting up PostgreSQL database..."
sudo -u postgres createdb hopempc_db
sudo -u postgres psql -c "CREATE USER hopempc_user WITH PASSWORD 'hopempc_password';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE hopempc_db TO hopempc_user;"
sudo -u postgres psql -c "ALTER USER hopempc_user CREATEDB;"

# Create environment file
echo "Creating environment configuration..."
cat > .env << EOF
DATABASE_URL=postgresql://hopempc_user:hopempc_password@localhost:5432/hopempc_db
SESSION_SECRET=$(openssl rand -hex 32)
NODE_ENV=production
PORT=3000
EOF

# Set up database schema
echo "Setting up database schema..."
npm run db:push

# Seed database with initial data
echo "Seeding database..."
npx tsx db/simple-seed.ts

# Build application
echo "Building application..."
npm run build

# Create PM2 ecosystem file
echo "Creating PM2 configuration..."
cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'hopempc',
    script: 'dist/index.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    }
  }]
}
EOF

# Start application with PM2
echo "Starting application with PM2..."
pm2 start ecosystem.config.js
pm2 save
pm2 startup

# Configure Nginx
echo "Configuring Nginx..."
sudo tee /etc/nginx/sites-available/hopempc << EOF
server {
    listen 80;
    server_name _;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

# Enable Nginx site
sudo ln -sf /etc/nginx/sites-available/hopempc /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

# Enable services
echo "Enabling services..."
sudo systemctl enable nginx
sudo systemctl enable postgresql

echo "======================================"
echo "DEPLOYMENT COMPLETED SUCCESSFULLY!"
echo "======================================"
echo ""
echo "Application Details:"
echo "- URL: http://your-server-ip"
echo "- Admin Email: admin@hopempc.org"
echo "- Admin Password: admin123"
echo "- Member Email: member@hopempc.org"
echo "- Member Password: member123"
echo ""
echo "Management Commands:"
echo "- View logs: pm2 logs hopempc"
echo "- Restart app: pm2 restart hopempc"
echo "- Stop app: pm2 stop hopempc"
echo "- View status: pm2 status"
echo ""
echo "Important: Change default passwords immediately!"
echo "======================================"