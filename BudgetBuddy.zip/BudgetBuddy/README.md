# HOPEMPC Cooperative Management System

A comprehensive web-based cooperative management system designed for financial tracking, loan management, member engagement, and administrative operations.

## Features

- **Member Portal**: Dashboard, profile management, capital shares tracking, loan applications
- **Admin Portal**: Member management, loan processing, payment verification, financial reporting
- **Real-time Chat**: Officer communication system with WebSocket support
- **Financial Management**: Income/expense tracking, fund management, dividend distribution
- **Secure Authentication**: Role-based access control with session management

## Quick VPS Deployment

### Prerequisites
- Ubuntu 20.04+ VPS with 2GB+ RAM
- Root or sudo access
- Domain name (optional)

### One-Click Installation

```bash
# Download and run the deployment script
wget https://raw.githubusercontent.com/your-repo/hopempc/main/deploy-vps.sh
chmod +x deploy-vps.sh
./deploy-vps.sh
```

### Access Your Application

After deployment:
- **URL**: `http://your-server-ip`
- **Admin Login**: `admin@hopempc.org` / `admin123`
- **Member Login**: `member@hopempc.org` / `member123`

**Important**: Change default passwords immediately after first login.

## Development Setup

### Prerequisites
- Node.js 20.x
- PostgreSQL 15+

### Local Development

```bash
# Clone repository
git clone [repository-url]
cd hopempc

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env file with your database credentials

# Push database schema
npm run db:push

# Seed database with initial data
npx tsx db/simple-seed.ts

# Start development server
npm run dev
```

## Technology Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for fast development and building
- **shadcn/ui** component library
- **Tailwind CSS** for styling
- **TanStack Query** for server state management
- **Wouter** for client-side routing

### Backend
- **Node.js** with Express.js
- **Drizzle ORM** with PostgreSQL
- **Passport.js** for authentication
- **WebSocket** for real-time features
- **Session-based authentication**

### Production
- **PM2** for process management
- **Nginx** as reverse proxy
- **PostgreSQL** for data persistence
- **Automated backups** and monitoring

## Project Structure

```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/    # Reusable UI components
│   │   ├── pages/         # Application pages
│   │   └── lib/           # Utilities and configurations
├── server/                # Backend Express application
│   ├── routes.ts          # API routes
│   ├── auth.ts            # Authentication logic
│   └── storage.ts         # Database operations
├── shared/                # Shared types and schemas
│   └── schema.ts          # Database schema definitions
├── db/                    # Database utilities
│   ├── index.ts           # Database connection
│   └── simple-seed.ts     # Database seeding
├── deploy-vps.sh          # VPS deployment script
└── VPS-DEPLOYMENT.md      # Detailed deployment guide
```

## Management Commands

### Application Management
```bash
pm2 status              # Check application status
pm2 logs hopempc        # View application logs
pm2 restart hopempc     # Restart application
pm2 stop hopempc        # Stop application
```

### Database Operations
```bash
npm run db:push         # Update database schema
npx tsx db/simple-seed.ts  # Seed database
psql -h localhost -U hopempc_user hopempc_db  # Connect to database
```

## Security Features

- **Role-based Access Control**: Separate admin and member interfaces
- **Session Management**: Secure session handling with PostgreSQL storage
- **Password Hashing**: scrypt-based password encryption
- **Input Validation**: Zod schema validation for all inputs
- **CSRF Protection**: Built-in session-based CSRF protection

## Backup and Recovery

- **Automatic Backups**: Daily database and application backups
- **7-day Retention**: Automatic cleanup of old backups
- **Manual Backup**: Run `./backup.sh` for immediate backup
- **Recovery**: Restore from `/var/backups/hopempc/` directory

## Support

For technical support:
1. Check application logs: `pm2 logs hopempc`
2. Review deployment guide: `VPS-DEPLOYMENT.md`
3. Verify service status: `sudo systemctl status nginx postgresql`

## License

MIT License - see LICENSE file for details.

---

**Production Ready**: This system includes automated deployment, process management, backups, and security configurations suitable for production use.