import { db } from "./index";
import { sql } from "drizzle-orm";

async function updateSchemaWithLoanApproval() {
  try {
    console.log("Starting schema update...");
    
    // Check if approvalStatus column exists
    const checkResult = await db.execute(sql`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'loans' AND column_name = 'approval_status'
    `);
    
    if (checkResult.rows.length === 0) {
      console.log("Adding approval columns to loans table...");
      
      // Add the new columns
      await db.execute(sql`
        ALTER TABLE loans 
        ADD COLUMN IF NOT EXISTS approval_status TEXT DEFAULT 'pending' NOT NULL,
        ADD COLUMN IF NOT EXISTS approved_by INTEGER REFERENCES users(id),
        ADD COLUMN IF NOT EXISTS approved_at TIMESTAMP,
        ADD COLUMN IF NOT EXISTS approval_note TEXT
      `);
      
      console.log("Added approval columns to loans table.");
    } else {
      console.log("Approval columns already exist in loans table.");
    }
    
    // Check if notifications table exists
    const tableCheckResult = await db.execute(sql`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_name = 'notifications'
    `);
    
    if (tableCheckResult.rows.length === 0) {
      console.log("Creating notifications table...");
      
      // Create the notifications table
      await db.execute(sql`
        CREATE TABLE IF NOT EXISTS notifications (
          id SERIAL PRIMARY KEY,
          user_id INTEGER NOT NULL REFERENCES users(id),
          title TEXT NOT NULL,
          message TEXT NOT NULL,
          type TEXT NOT NULL,
          related_id INTEGER,
          is_read BOOLEAN DEFAULT FALSE NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
        )
      `);
      
      console.log("Created notifications table.");
    } else {
      console.log("Notifications table already exists.");
    }
    
    console.log("Schema update completed successfully.");
  } catch (error) {
    console.error("Error updating schema:", error);
  } finally {
    process.exit(0);
  }
}

updateSchemaWithLoanApproval();
