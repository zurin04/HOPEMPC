import { db } from "./index";
import { users } from "@shared/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "../server/auth";

async function fixTestUser() {
  try {
    console.log("Creating test admin user...");

    // Delete existing user if exists
    await db.delete(users).where(eq(users.email, 'admin@test.com'));

    // Create new admin user with properly hashed password
    const hashedPassword = await hashPassword('admin123');
    
    const [newUser] = await db.insert(users).values({
      email: 'admin@test.com',
      password: hashedPassword,
      name: 'Test Admin',
      firstName: 'Test',
      lastName: 'Admin',
      role: 'admin',
      status: 'active'
    }).returning();

    console.log("Created test admin user:");
    console.log("Email: admin@test.com");
    console.log("Password: admin123");
    console.log("User ID:", newUser.id);

    // Also create a test member who is an officer
    const memberPassword = await hashPassword('member123');
    
    const [memberUser] = await db.insert(users).values({
      email: 'officer@test.com', 
      password: memberPassword,
      name: 'Test Officer',
      firstName: 'Test',
      lastName: 'Officer',
      role: 'member',
      status: 'active'
    }).returning();

    console.log("Created test officer user:");
    console.log("Email: officer@test.com");
    console.log("Password: member123");
    console.log("User ID:", memberUser.id);

  } catch (error) {
    console.error("Error creating test users:", error);
  }
}

fixTestUser();