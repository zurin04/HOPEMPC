import { db } from "./index";
import { users } from "@shared/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "../server/auth";

/**
 * This script fixes users with unhashed passwords by hashing them.
 * It operates on passwords missing the '.' separator that indicates a proper hash+salt format.
 */
async function fixPasswords() {
  try {
    console.log("Starting password fix script...");
    
    // Get all users
    const allUsers = await db.select().from(users);
    console.log(`Found ${allUsers.length} total users`);
    
    // Count how many users have unhashed passwords
    const usersWithUnhashedPasswords = allUsers.filter(user => !user.password.includes("."));
    console.log(`Found ${usersWithUnhashedPasswords.length} users with unhashed passwords`);    
    
    // Fix each unhashed password
    for (const user of usersWithUnhashedPasswords) {
      console.log(`Fixing password for user: ${user.name} (ID: ${user.id})`);
      
      // Hash the existing plain text password
      const hashedPassword = await hashPassword(user.password);
      
      // Update the user record
      await db.update(users)
        .set({ password: hashedPassword })
        .where(eq(users.id, user.id));
      
      console.log(`Password updated for user: ${user.name}`);
    }
    
    console.log("Password fix complete!");
  } catch (error) {
    console.error("Error fixing passwords:", error);
  }
}

fixPasswords();
