import { db } from "./index";
import { users, officers, chatMessages } from "@shared/schema";
import { eq } from "drizzle-orm";

async function addOfficersAndChat() {
  try {
    console.log("Adding officers and chat messages...");

    // Get some existing users
    const existingUsers = await db.query.users.findMany({
      where: eq(users.role, 'member'),
      limit: 3
    });

    if (existingUsers.length < 2) {
      console.log("Not enough users to assign as officers");
      return;
    }

    // Make first user a Chairperson
    const chairperson = existingUsers[0];
    await db.insert(officers).values({
      userId: chairperson.id,
      position: 'Chairperson',
      assignedAt: new Date()
    }).onConflictDoNothing();

    // Make second user a Secretary
    const secretary = existingUsers[1];
    await db.insert(officers).values({
      userId: secretary.id,
      position: 'Secretary',
      assignedAt: new Date()
    }).onConflictDoNothing();

    console.log(`Assigned ${chairperson.name} as Chairperson`);
    console.log(`Assigned ${secretary.name} as Secretary`);

    // Add some chat messages
    const chatData = [
      {
        userId: chairperson.id,
        userName: chairperson.name,
        userRole: 'member',
        content: 'Hello everyone! Welcome to the officer chat.',
        messageType: 'message' as const,
        createdAt: new Date(Date.now() - 60000 * 30) // 30 minutes ago
      },
      {
        userId: secretary.id,
        userName: secretary.name,
        userRole: 'member',
        content: 'Thank you! This will help us coordinate better.',
        messageType: 'message' as const,
        createdAt: new Date(Date.now() - 60000 * 25) // 25 minutes ago
      },
      {
        userId: chairperson.id,
        userName: chairperson.name,
        userRole: 'member',
        content: 'We should discuss the upcoming member meeting agenda.',
        messageType: 'message' as const,
        createdAt: new Date(Date.now() - 60000 * 20) // 20 minutes ago
      },
      {
        userId: secretary.id,
        userName: secretary.name,
        userRole: 'member',
        content: 'I can prepare the meeting minutes template.',
        messageType: 'message' as const,
        createdAt: new Date(Date.now() - 60000 * 15) // 15 minutes ago
      }
    ];

    for (const chat of chatData) {
      await db.insert(chatMessages).values(chat).onConflictDoNothing();
    }

    console.log("Added sample chat messages");
    console.log("Officers and chat setup complete!");

  } catch (error) {
    console.error("Error adding officers and chat:", error);
  }
}

addOfficersAndChat();