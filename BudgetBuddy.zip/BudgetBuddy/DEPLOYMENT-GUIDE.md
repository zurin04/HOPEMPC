# HOPEMPC VPS Deployment Guide

## Overview

The HOPEMPC Cooperative Management System includes a comprehensive one-click deployment script (`deploy.sh`) that automatically sets up a production-ready environment on Ubuntu VPS servers.

## Prerequisites

### Server Requirements
- Ubuntu 20.04+ VPS with minimum 2GB RAM
- Regular user account with sudo privileges
- Root SSH access or sudo-enabled user
- At least 10GB free disk space

### Local Requirements
- Git installed on your local machine
- SSH access to your VPS

## Quick Deployment

### 1. Clone and Upload
```bash
# On your local machine
git clone <repository-url>
cd hopempc

# Upload to VPS (replace with your server details)
scp -r . username@your-server-ip:/home/username/hopempc
```

### 2. Connect to VPS
```bash
ssh username@your-server-ip
cd hopempc
```

### 3. Run Deployment
```bash
chmod +x deploy.sh
./deploy.sh
```

The deployment script will automatically:
- Install Node.js 20.x, PostgreSQL, Nginx, and PM2
- Create and configure the database
- Build the application for production
- Set up reverse proxy with Nginx
- Configure firewall and security settings
- Start the application with PM2 process management
- Set up automatic backups and monitoring

## What Gets Installed

### System Components
- **Node.js 20.x**: Runtime environment
- **PostgreSQL**: Database server with optimized configuration
- **Nginx**: Reverse proxy and web server
- **PM2**: Process manager for production
- **UFW**: Firewall configuration

### Application Setup
- Production build with optimized assets
- Environment configuration with secure secrets
- Database schema creation and seeding
- SSL-ready Nginx configuration
- Automatic backup system

### Security Features
- Firewall configuration (ports 22, 80, 443)
- Secure database user with encrypted password
- Session secrets with cryptographically secure generation
- Security headers in Nginx configuration
- Process isolation with PM2

## Post-Deployment

### Access Your Application
After successful deployment, access your application at:
```
http://your-server-ip
```

### Default Credentials
**Admin Account:**
- Email: admin@hopempc.org
- Password: admin123

**Member Account:**
- Email: member@hopempc.org
- Password: member123

⚠️ **Important**: Change these default passwords immediately after first login!

### Management Commands
The deployment creates a `manage.sh` script for easy administration:

```bash
# Check application status
./manage.sh status

# Restart application
./manage.sh restart

# View real-time logs
./manage.sh logs

# Create manual backup
./manage.sh backup

# Update application
./manage.sh update
```

### Service Management
```bash
# Check system services
sudo systemctl status nginx postgresql

# Check PM2 processes
pm2 status
pm2 logs hopempc

# Check application logs
tail -f logs/combined.log
```

## Configuration Files

### Environment Variables
Located at `/var/www/hopempc/.env`:
```
DATABASE_URL=postgresql://hopempc_user:PASSWORD@localhost:5432/hopempc_db
SESSION_SECRET=RANDOM_SECRET
NODE_ENV=production
PORT=5000
```

### PM2 Configuration
Located at `/var/www/hopempc/ecosystem.config.cjs`:
- Process monitoring and auto-restart
- Memory management (1GB limit)
- Log rotation and management
- Environment variable injection

### Nginx Configuration
Located at `/etc/nginx/sites-available/hopempc`:
- Reverse proxy to Node.js application
- WebSocket support for real-time features
- Security headers
- Request timeout and size limits

## Backup System

### Automatic Backups
- Daily backups scheduled at 2:00 AM
- Database dumps and application files
- 7-day retention policy
- Stored in `/var/backups/hopempc/`

### Manual Backup
```bash
# Create immediate backup
./backup.sh

# List existing backups
ls -la /var/backups/hopempc/
```

### Restore from Backup
```bash
# Restore database
PGPASSWORD=your_db_password psql -h localhost -U hopempc_user hopempc_db < backup_file.sql

# Restore application files
tar -xzf backup_file.tar.gz -C /var/www/
```

## SSL Certificate Setup

### Using Let's Encrypt (Recommended)
```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Obtain and configure SSL certificate
sudo certbot --nginx -d yourdomain.com

# Test automatic renewal
sudo certbot renew --dry-run
```

### Manual SSL Configuration
Edit `/etc/nginx/sites-available/hopempc` to add SSL configuration and restart Nginx.

## Monitoring and Logs

### Application Logs
```bash
# Real-time application logs
pm2 logs hopempc

# View log files
tail -f /var/www/hopempc/logs/combined.log
tail -f /var/www/hopempc/logs/err.log
```

### System Monitoring
```bash
# Check system resources
htop
df -h
free -h

# Check service status
sudo systemctl status nginx postgresql
pm2 status
```

### Database Monitoring
```bash
# Connect to database
sudo -u postgres psql hopempc_db

# Check database size
sudo -u postgres psql -c "SELECT pg_size_pretty(pg_database_size('hopempc_db'));"
```

## Troubleshooting

### Common Issues

**Application Won't Start:**
```bash
# Check PM2 status
pm2 status

# View error logs
pm2 logs hopempc --err

# Restart application
pm2 restart hopempc
```

**Database Connection Issues:**
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Test database connection
sudo -u postgres psql hopempc_db -c "SELECT version();"

# Check connection from application
DATABASE_URL=your_url node -e "console.log('Testing connection...')"
```

**Nginx Issues:**
```bash
# Test Nginx configuration
sudo nginx -t

# Check Nginx status
sudo systemctl status nginx

# View Nginx logs
sudo tail -f /var/log/nginx/error.log
```

### Performance Optimization

**Database Optimization:**
```bash
# Analyze database performance
sudo -u postgres psql hopempc_db -c "SELECT * FROM pg_stat_activity;"

# Vacuum and analyze
sudo -u postgres psql hopempc_db -c "VACUUM ANALYZE;"
```

**Application Optimization:**
```bash
# Monitor memory usage
pm2 monit

# Adjust PM2 configuration if needed
pm2 restart ecosystem.config.cjs
```

## Updates and Maintenance

### Application Updates
```bash
# Using the management script
./manage.sh update

# Manual update process
git pull
npm install
npm run build
pm2 restart hopempc
```

### System Updates
```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Update Node.js (if needed)
# Follow official Node.js update procedures
```

### Database Maintenance
```bash
# Regular maintenance
sudo -u postgres psql hopempc_db -c "VACUUM ANALYZE;"

# Check database integrity
sudo -u postgres psql hopempc_db -c "SELECT * FROM pg_stat_database WHERE datname='hopempc_db';"
```

## Security Considerations

### Regular Security Tasks
1. Update system packages monthly
2. Change default passwords immediately
3. Monitor access logs regularly
4. Review user accounts and permissions
5. Keep SSL certificates updated

### Additional Security Measures
```bash
# Install fail2ban for SSH protection
sudo apt install fail2ban

# Configure automatic security updates
sudo apt install unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades
```

## Support and Maintenance

### Log Locations
- Application logs: `/var/www/hopempc/logs/`
- Nginx logs: `/var/log/nginx/`
- PostgreSQL logs: `/var/log/postgresql/`
- System logs: `/var/log/syslog`

### Configuration Files
- Application: `/var/www/hopempc/.env`
- PM2: `/var/www/hopempc/ecosystem.config.cjs`
- Nginx: `/etc/nginx/sites-available/hopempc`
- PostgreSQL: `/etc/postgresql/*/main/postgresql.conf`

### Contact and Resources
- Check `deployment-info.txt` for deployment-specific details
- Review application logs for troubleshooting
- Consult PostgreSQL and Nginx documentation for advanced configuration

---

**Last Updated:** June 26, 2025
**Script Version:** deploy.sh v1.0
**Tested On:** Ubuntu 20.04, 22.04