#!/bin/bash

# Test script to validate deployment readiness
# This script checks all components without actually deploying

echo "======================================"
echo "HOPEMPC Deployment Readiness Test"
echo "======================================"

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_test() {
    echo -e "${GREEN}[TEST]${NC} $1"
}

print_pass() {
    echo -e "${GREEN}[PASS]${NC} $1"
}

print_fail() {
    echo -e "${RED}[FAIL]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

TESTS_PASSED=0
TESTS_FAILED=0

# Test 1: Check required files exist
print_test "Checking required files..."
required_files=("package.json" "drizzle.config.ts" "vite.config.ts" "db/simple-seed.ts" "db/fix-passwords.ts")
for file in "${required_files[@]}"; do
    if [[ -f "$file" ]]; then
        print_pass "Found $file"
        ((TESTS_PASSED++))
    else
        print_fail "Missing $file"
        ((TESTS_FAILED++))
    fi
done

# Test 2: Check package.json scripts
print_test "Checking package.json scripts..."
required_scripts=("build" "db:push" "dev")
for script in "${required_scripts[@]}"; do
    if grep -q "\"$script\":" package.json; then
        print_pass "Script '$script' found"
        ((TESTS_PASSED++))
    else
        print_fail "Script '$script' missing"
        ((TESTS_FAILED++))
    fi
done

# Test 3: Check deployment script syntax
print_test "Checking deploy.sh syntax..."
if bash -n deploy.sh; then
    print_pass "deploy.sh syntax valid"
    ((TESTS_PASSED++))
else
    print_fail "deploy.sh has syntax errors"
    ((TESTS_FAILED++))
fi

# Test 4: Check deployment script permissions
print_test "Checking deploy.sh permissions..."
if [[ -x "deploy.sh" ]]; then
    print_pass "deploy.sh is executable"
    ((TESTS_PASSED++))
else
    print_fail "deploy.sh is not executable"
    ((TESTS_FAILED++))
fi

# Test 5: Check database schema files
print_test "Checking database schema..."
if [[ -f "shared/schema.ts" ]]; then
    if grep -q "pgTable" shared/schema.ts; then
        print_pass "Database schema found"
        ((TESTS_PASSED++))
    else
        print_fail "Database schema incomplete"
        ((TESTS_FAILED++))
    fi
else
    print_fail "shared/schema.ts missing"
    ((TESTS_FAILED++))
fi

# Test 6: Check environment template
print_test "Checking environment configuration..."
if [[ -f ".env.template" ]]; then
    print_pass ".env.template found"
    ((TESTS_PASSED++))
else
    print_warn ".env.template missing (optional)"
fi

# Test 7: Check TypeScript configuration
print_test "Checking TypeScript configuration..."
if [[ -f "tsconfig.json" ]]; then
    print_pass "tsconfig.json found"
    ((TESTS_PASSED++))
else
    print_fail "tsconfig.json missing"
    ((TESTS_FAILED++))
fi

# Test 8: Check build readiness
print_test "Testing build process..."
if npm run build > build-test.log 2>&1; then
    print_pass "Build successful"
    ((TESTS_PASSED++))
    rm -f build-test.log
else
    print_fail "Build failed - check build-test.log"
    ((TESTS_FAILED++))
fi

# Test 9: Check key deployment components
print_test "Checking deployment components..."
deployment_components=("client/src/main.tsx" "server/index.ts" "server/routes.ts")
for component in "${deployment_components[@]}"; do
    if [[ -f "$component" ]]; then
        print_pass "Found $component"
        ((TESTS_PASSED++))
    else
        print_fail "Missing $component"
        ((TESTS_FAILED++))
    fi
done

# Summary
echo ""
echo "======================================"
echo "TEST SUMMARY"
echo "======================================"
echo "Tests Passed: $TESTS_PASSED"
echo "Tests Failed: $TESTS_FAILED"

if [[ $TESTS_FAILED -eq 0 ]]; then
    print_pass "All tests passed! Ready for deployment."
    echo ""
    echo "To deploy to VPS:"
    echo "1. Copy all files to your Ubuntu VPS"
    echo "2. Run: chmod +x deploy.sh"
    echo "3. Run: ./deploy.sh"
    echo ""
    exit 0
else
    print_fail "Some tests failed. Please fix issues before deploying."
    echo ""
    exit 1
fi