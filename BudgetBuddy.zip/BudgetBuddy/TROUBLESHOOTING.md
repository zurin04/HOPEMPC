# HOPEMPC VPS Deployment Troubleshooting Guide

## Common Deployment Issues and Solutions

### Database Permission Errors

**Error**: `permission denied for schema public`

**Solution**:
```bash
# Fix PostgreSQL permissions
sudo -u postgres psql -d hopempc_db -c "GRANT ALL ON SCHEMA public TO hopempc_user;"
sudo -u postgres psql -d hopempc_db -c "GRANT CREATE ON SCHEMA public TO hopempc_user;"
sudo -u postgres psql -d hopempc_db -c "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO hopempc_user;"
sudo -u postgres psql -d hopempc_db -c "ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO hopempc_user;"
```

### PM2 Configuration Issues

**Error**: `module is not defined` in ecosystem.config.js

**Solution**: Use the `.cjs` extension for PM2 config files:
```bash
# Rename and fix PM2 config
mv ecosystem.config.js ecosystem.config.cjs
pm2 start ecosystem.config.cjs
```

### Environment Variable Issues

**Error**: `DATABASE_URL must be set`

**Solution**: Ensure environment variables are properly exported:
```bash
# Add to your deployment script or run manually
export DATABASE_URL=postgresql://hopempc_user:hopempc_secure_password@localhost:5432/hopempc_db
export SESSION_SECRET=$(openssl rand -hex 32)
export NODE_ENV=production
```

### Database Connection Issues

**Error**: Connection refused or authentication failed

**Solutions**:

1. **Check PostgreSQL service**:
```bash
sudo systemctl status postgresql
sudo systemctl start postgresql
```

2. **Verify database exists**:
```bash
sudo -u postgres psql -l | grep hopempc
```

3. **Test database connection**:
```bash
sudo -u postgres psql -d hopempc_db -c "SELECT version();"
```

4. **Reset database if needed**:
```bash
sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS hopempc_db;
DROP USER IF EXISTS hopempc_user;
CREATE DATABASE hopempc_db;
CREATE USER hopempc_user WITH ENCRYPTED PASSWORD 'hopempc_secure_password';
GRANT ALL PRIVILEGES ON DATABASE hopempc_db TO hopempc_user;
ALTER USER hopempc_user CREATEDB;
\q
EOF
```

### Build Failures

**Error**: Build process fails during `npm run build`

**Solutions**:

1. **Check Node.js version**:
```bash
node --version  # Should be 20.x
```

2. **Clear cache and reinstall**:
```bash
rm -rf node_modules package-lock.json
npm install
```

3. **Check for TypeScript errors**:
```bash
npm run check
```

### Nginx Configuration Issues

**Error**: Nginx test fails or site not accessible

**Solutions**:

1. **Test Nginx configuration**:
```bash
sudo nginx -t
```

2. **Check Nginx status**:
```bash
sudo systemctl status nginx
```

3. **Remove conflicting sites**:
```bash
sudo rm -f /etc/nginx/sites-enabled/default
sudo systemctl reload nginx
```

4. **Check port 80 availability**:
```bash
sudo netstat -tulpn | grep :80
```

### Application Startup Issues

**Error**: Application fails to start with PM2

**Solutions**:

1. **Check PM2 status**:
```bash
pm2 status
pm2 logs hopempc
```

2. **Check if port 3000 is available**:
```bash
sudo netstat -tulpn | grep :3000
```

3. **Restart application**:
```bash
pm2 restart hopempc
```

4. **Check application logs**:
```bash
pm2 logs hopempc --lines 50
```

### SSL Certificate Issues

**Error**: SSL certificate setup fails

**Solutions**:

1. **Install Certbot**:
```bash
sudo apt install certbot python3-certbot-nginx
```

2. **Get certificate**:
```bash
sudo certbot --nginx -d yourdomain.com
```

3. **Test certificate renewal**:
```bash
sudo certbot renew --dry-run
```

## Manual Recovery Steps

### Complete Reset and Redeploy

If deployment fails completely:

```bash
# 1. Stop all services
pm2 delete all
sudo systemctl stop nginx

# 2. Remove application directory
sudo rm -rf /var/www/hopempc

# 3. Reset database
sudo -u postgres psql -c "DROP DATABASE IF EXISTS hopempc_db;"
sudo -u postgres psql -c "DROP USER IF EXISTS hopempc_user;"

# 4. Run deployment script again
./deploy-simple.sh
```

### Database Recovery

To restore from backup:

```bash
# Restore database
sudo -u postgres psql -c "DROP DATABASE IF EXISTS hopempc_db;"
sudo -u postgres psql -c "CREATE DATABASE hopempc_db;"
sudo -u postgres psql hopempc_db < /var/backups/hopempc/backup_file.sql
```

## Service Management Commands

### PostgreSQL
```bash
sudo systemctl status postgresql    # Check status
sudo systemctl start postgresql     # Start service
sudo systemctl stop postgresql      # Stop service
sudo systemctl restart postgresql   # Restart service
```

### Nginx
```bash
sudo systemctl status nginx         # Check status
sudo systemctl start nginx          # Start service
sudo systemctl stop nginx           # Stop service
sudo systemctl reload nginx         # Reload config
```

### PM2
```bash
pm2 status                          # Check all processes
pm2 start hopempc                    # Start application
pm2 stop hopempc                     # Stop application
pm2 restart hopempc                  # Restart application
pm2 delete hopempc                   # Remove process
pm2 logs hopempc                     # View logs
```

## Log Locations

- **Application logs**: `pm2 logs hopempc`
- **Nginx access logs**: `/var/log/nginx/access.log`
- **Nginx error logs**: `/var/log/nginx/error.log`
- **PostgreSQL logs**: `/var/log/postgresql/`
- **System logs**: `journalctl -u nginx` or `journalctl -u postgresql`

## Getting Help

1. Check service status: `sudo systemctl status nginx postgresql`
2. Review application logs: `pm2 logs hopempc`
3. Test database connection manually
4. Verify environment variables are set
5. Check firewall settings: `sudo ufw status`

## Contact Support

If issues persist after following this guide:
1. Collect logs from all services
2. Note the exact error messages
3. Document the steps taken before the error occurred
4. Contact system administrator with this information