import { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { getInitials } from "@/lib/utils";
import { format } from "date-fns";
import { Send, AlertCircle, Users } from "lucide-react";

type ChatMessage = {
  type: 'message' | 'system' | 'error';
  userId: number;
  userName: string;
  userRole: string;
  content: string;
  timestamp: string;
};

type OnlineUser = {
  userId: number;
  userName: string;
  userRole: string;
};

export function OfficerChat() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [onlineUsers, setOnlineUsers] = useState<OnlineUser[]>([]);
  const [connected, setConnected] = useState(false);
  const [showUsers, setShowUsers] = useState(false);
  const [isOfficer, setIsOfficer] = useState(false);
  const websocketRef = useRef<WebSocket | null>(null);
  const messageEndRef = useRef<HTMLDivElement>(null);

  // Check if user is an officer
  const { data: officerStatus, isLoading: statusLoading } = useQuery({
    queryKey: ["/api/user/officer-status"],
    enabled: !!user,
  });

  useEffect(() => {
    if (user && !statusLoading && officerStatus) {
      console.log('Officer status response:', officerStatus);
      setIsOfficer(officerStatus.isOfficer || false);
    }
  }, [user, officerStatus, statusLoading]);

  // Connect to WebSocket when component mounts
  useEffect(() => {
    if (!user) return;

    // Create WebSocket connection
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);
    websocketRef.current = socket;

    socket.onopen = () => {
      console.log('WebSocket connection established');
      setConnected(true);
      
      // Send authentication message
      socket.send(JSON.stringify({
        type: 'auth',
        userId: user.id,
        userName: user.name,
        userRole: user.role
      }));
      
      // Add initial system message
      setMessages([{
        type: 'system',
        userId: 0,
        userName: 'System',
        userRole: 'system',
        content: 'Welcome to the Officers Chat!',
        timestamp: new Date().toISOString()
      }]);
    };

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      // Handle message
      if (data.type === 'message' || data.type === 'system') {
        setMessages(prev => [...prev, data]);
      }
      // Handle online users update
      else if (data.type === 'users') {
        setOnlineUsers(data.users);
      }
      // Handle errors
      else if (data.type === 'error') {
        console.error('WebSocket error:', data.content);
      }
    };

    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
      setMessages(prev => [
        ...prev, 
        {
          type: 'error',
          userId: 0,
          userName: 'System',
          userRole: 'system',
          content: 'Connection error. Please try again later.',
          timestamp: new Date().toISOString()
        }
      ]);
    };

    socket.onclose = () => {
      console.log('WebSocket connection closed');
      setConnected(false);
      setMessages(prev => [
        ...prev, 
        {
          type: 'system',
          userId: 0,
          userName: 'System',
          userRole: 'system',
          content: 'Connection closed. You may need to refresh the page to reconnect.',
          timestamp: new Date().toISOString()
        }
      ]);
    };

    // Clean up on unmount
    return () => {
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.close();
      }
    };
  }, [user]);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messageEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Send message
  const sendMessage = () => {
    if (!inputMessage.trim() || !websocketRef.current || websocketRef.current.readyState !== WebSocket.OPEN) return;

    websocketRef.current.send(JSON.stringify({
      type: 'message',
      content: inputMessage
    }));

    setInputMessage('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  // Check if user is an officer or admin
  if (!user || !isOfficer) {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle>Officer Chat</CardTitle>
          <CardDescription>Real-time communication for cooperative officers</CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center h-64">
          <div className="text-center">
            <AlertCircle className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium">Access Restricted</h3>
            <p className="text-muted-foreground mt-2">Only assigned officers can access the chat system.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full h-[calc(100vh-200px)] flex flex-col">
      <CardHeader className="pb-3 pt-4">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Officer Chat</CardTitle>
            <CardDescription className="flex items-center mt-1">
              <span className={`h-2 w-2 rounded-full mr-2 ${connected ? 'bg-green-500' : 'bg-red-500'}`}></span>
              {connected ? 'Connected' : 'Disconnected'}
            </CardDescription>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowUsers(!showUsers)}
            className="flex items-center gap-1"
          >
            <Users className="h-4 w-4" />
            <span className="ml-1">Users</span>
            <Badge variant="secondary" className="ml-1">{onlineUsers.length}</Badge>
          </Button>
        </div>
      </CardHeader>
      <CardContent className="flex-grow overflow-hidden p-0">
        <div className="flex h-full">
          {/* Chat Messages */}
          <div className={`${showUsers ? 'w-2/3' : 'w-full'} h-full flex flex-col`}>
            <ScrollArea className="flex-grow p-4">
              {messages.map((msg, idx) => (
                <div key={idx} className="mb-4 last:mb-0">
                  {msg.type === 'system' ? (
                    <div className="flex justify-center">
                      <Badge variant="outline" className="text-xs text-muted-foreground">
                        {msg.content}
                      </Badge>
                    </div>
                  ) : (
                    <div className={`flex ${msg.userId === user.id ? 'justify-end' : 'justify-start'}`}>
                      <div className={`flex ${msg.userId === user.id ? 'flex-row-reverse' : 'flex-row'} items-start gap-2 max-w-[80%]`}>
                        <Avatar className="h-8 w-8">
                          <AvatarFallback>{getInitials(msg.userName)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className={`text-sm font-medium ${msg.userId === user.id ? 'text-right' : ''}`}>
                              {msg.userName}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              {format(new Date(msg.timestamp), 'h:mm a')}
                            </span>
                          </div>
                          <div className={`rounded-lg px-3 py-2 text-sm break-words ${msg.userId === user.id ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                            {msg.content}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
              <div ref={messageEndRef} />
            </ScrollArea>
          </div>

          {/* Online Users */}
          {showUsers && (
            <div className="w-1/3 border-l h-full">
              <div className="p-3 border-b">
                <h3 className="text-sm font-medium">Online Officers</h3>
              </div>
              <ScrollArea className="h-full">
                <div className="p-3">
                  {onlineUsers.map((u) => (
                    <div key={u.userId} className="flex items-center gap-2 mb-3 last:mb-0">
                      <div className="relative">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback>{getInitials(u.userName)}</AvatarFallback>
                        </Avatar>
                        <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full bg-green-500 ring-1 ring-white"></span>
                      </div>
                      <div>
                        <p className="text-sm font-medium line-clamp-1">{u.userName}</p>
                        <p className="text-xs text-muted-foreground capitalize">{u.userRole}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="p-3 border-t">
        <div className="flex w-full gap-2">
          <Input
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyDown={handleKeyPress}
            placeholder="Type a message..."
            disabled={!connected}
            className="flex-grow"
          />
          <Button 
            onClick={sendMessage} 
            disabled={!connected || !inputMessage.trim()}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
