import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { User, CapitalShare, MemberSavings } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2, Eye, EyeOff, DollarSign, Plus, Minus } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { format } from "date-fns";

const memberEditSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  firstName: z.string().optional(),
  lastName: z.string().optional(),
  middleName: z.string().optional(),
  email: z.string().email("Invalid email address"),
  address: z.string().optional(),
  occupation: z.string().optional(),
  birthplace: z.string().optional(),
  contactNumber: z.string().optional(),
  civilStatus: z.string().optional(),
  numberOfChildren: z.coerce.number().min(0).optional(),
  parentsName: z.string().optional(),
  sourceOfIncome: z.string().optional(),
  status: z.enum(["active", "inactive", "pending"]),
});

const passwordResetSchema = z.object({
  newPassword: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(6, "Password must be at least 6 characters"),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

const cbuUpdateSchema = z.object({
  amount: z.coerce.number().min(0, "Amount must be positive"),
});

const savingsTransactionSchema = z.object({
  amount: z.coerce.number().min(0.01, "Amount must be greater than 0"),
  transactionType: z.enum(["deposit", "withdrawal"]),
  note: z.string().optional(),
});

type MemberEditDialogProps = {
  member: User | null;
  isOpen: boolean;
  onClose: () => void;
};

export function AdminMemberEditDialog({ member, isOpen, onClose }: MemberEditDialogProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [activeTab, setActiveTab] = useState("profile");
  const { toast } = useToast();

  const memberForm = useForm<z.infer<typeof memberEditSchema>>({
    resolver: zodResolver(memberEditSchema),
    defaultValues: {
      name: "",
      firstName: "",
      lastName: "",
      middleName: "",
      email: "",
      address: "",
      occupation: "",
      birthplace: "",
      contactNumber: "",
      civilStatus: "",
      numberOfChildren: 0,
      parentsName: "",
      sourceOfIncome: "",
      status: "active",
    },
  });

  const passwordForm = useForm<z.infer<typeof passwordResetSchema>>({
    resolver: zodResolver(passwordResetSchema),
    defaultValues: {
      newPassword: "",
      confirmPassword: "",
    },
  });

  const cbuForm = useForm<z.infer<typeof cbuUpdateSchema>>({
    resolver: zodResolver(cbuUpdateSchema),
    defaultValues: {
      amount: 0,
    },
  });

  const savingsForm = useForm<z.infer<typeof savingsTransactionSchema>>({
    resolver: zodResolver(savingsTransactionSchema),
    defaultValues: {
      amount: 0,
      transactionType: "deposit",
      note: "",
    },
  });

  // Get member's capital share
  const { data: capitalShare } = useQuery<CapitalShare>({
    queryKey: ["/api/admin/capital-shares", member?.id],
    enabled: !!member?.id && isOpen,
  });

  // Get member's savings
  const { data: savingsData, refetch: refetchSavings } = useQuery<{transactions: MemberSavings[], balance: number}>({
    queryKey: ["/api/admin/members", member?.id, "savings"],
    enabled: !!member?.id && isOpen,
  });

  // Update member information
  const updateMemberMutation = useMutation({
    mutationFn: async (data: z.infer<typeof memberEditSchema>) => {
      const response = await fetch(`/api/admin/members/${member?.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to update member");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Member information updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/members"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update member information",
        variant: "destructive",
      });
    },
  });

  // Reset password
  const resetPasswordMutation = useMutation({
    mutationFn: async (data: z.infer<typeof passwordResetSchema>) => {
      const response = await fetch(`/api/admin/members/${member?.id}/reset-password`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ newPassword: data.newPassword }),
      });
      if (!response.ok) throw new Error("Failed to reset password");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Password reset successfully",
      });
      passwordForm.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to reset password",
        variant: "destructive",
      });
    },
  });

  // Update CBU
  const updateCBUMutation = useMutation({
    mutationFn: async (data: z.infer<typeof cbuUpdateSchema>) => {
      const response = await fetch(`/api/admin/members/${member?.id}/capital-shares`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to update CBU");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "CBU amount updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/capital-shares", member?.id] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update CBU amount",
        variant: "destructive",
      });
    },
  });

  // Add savings transaction
  const addSavingsMutation = useMutation({
    mutationFn: async (data: z.infer<typeof savingsTransactionSchema>) => {
      const response = await fetch(`/api/admin/members/${member?.id}/savings`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Failed to add savings transaction");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Savings transaction added successfully",
      });
      savingsForm.reset();
      refetchSavings();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add savings transaction",
        variant: "destructive",
      });
    },
  });

  // Update form values when member changes
  useEffect(() => {
    if (member) {
      memberForm.reset({
        name: member.name || "",
        firstName: member.firstName || "",
        lastName: member.lastName || "",
        middleName: member.middleName || "",
        email: member.email || "",
        address: member.address || "",
        occupation: member.occupation || "",
        birthplace: member.birthplace || "",
        contactNumber: member.contactNumber || "",
        civilStatus: member.civilStatus || "",
        numberOfChildren: member.numberOfChildren || 0,
        parentsName: member.parentsName || "",
        sourceOfIncome: member.sourceOfIncome || "",
        status: member.status as "active" | "inactive" | "pending",
      });

      if (capitalShare) {
        cbuForm.reset({
          amount: capitalShare.amount,
        });
      }
    }
  }, [member, capitalShare, memberForm, cbuForm]);

  const onSubmitMember = (data: z.infer<typeof memberEditSchema>) => {
    updateMemberMutation.mutate(data);
  };

  const onSubmitPassword = (data: z.infer<typeof passwordResetSchema>) => {
    resetPasswordMutation.mutate(data);
  };

  const onSubmitCBU = (data: z.infer<typeof cbuUpdateSchema>) => {
    updateCBUMutation.mutate(data);
  };

  const onSubmitSavings = (data: z.infer<typeof savingsTransactionSchema>) => {
    addSavingsMutation.mutate(data);
  };

  if (!member) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Member - {member.name}</DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
            <TabsTrigger value="cbu">CBU</TabsTrigger>
            <TabsTrigger value="savings">Savings</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Member Information</CardTitle>
                <CardDescription>Update member's personal information</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={memberForm.handleSubmit(onSubmitMember)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        {...memberForm.register("name")}
                        placeholder="Enter full name"
                      />
                      {memberForm.formState.errors.name && (
                        <p className="text-sm text-red-500">{memberForm.formState.errors.name.message}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        {...memberForm.register("email")}
                        placeholder="Enter email address"
                      />
                      {memberForm.formState.errors.email && (
                        <p className="text-sm text-red-500">{memberForm.formState.errors.email.message}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        {...memberForm.register("firstName")}
                        placeholder="Enter first name"
                      />
                    </div>

                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        {...memberForm.register("lastName")}
                        placeholder="Enter last name"
                      />
                    </div>

                    <div>
                      <Label htmlFor="middleName">Middle Name</Label>
                      <Input
                        id="middleName"
                        {...memberForm.register("middleName")}
                        placeholder="Enter middle name"
                      />
                    </div>

                    <div>
                      <Label htmlFor="contactNumber">Contact Number</Label>
                      <Input
                        id="contactNumber"
                        {...memberForm.register("contactNumber")}
                        placeholder="Enter contact number"
                      />
                    </div>

                    <div>
                      <Label htmlFor="occupation">Occupation</Label>
                      <Input
                        id="occupation"
                        {...memberForm.register("occupation")}
                        placeholder="Enter occupation"
                      />
                    </div>

                    <div>
                      <Label htmlFor="civilStatus">Civil Status</Label>
                      <Select
                        value={memberForm.watch("civilStatus") || ""}
                        onValueChange={(value) => memberForm.setValue("civilStatus", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select civil status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="single">Single</SelectItem>
                          <SelectItem value="married">Married</SelectItem>
                          <SelectItem value="divorced">Divorced</SelectItem>
                          <SelectItem value="widowed">Widowed</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="numberOfChildren">Number of Children</Label>
                      <Input
                        id="numberOfChildren"
                        type="number"
                        min="0"
                        {...memberForm.register("numberOfChildren")}
                        placeholder="Enter number of children"
                      />
                    </div>

                    <div>
                      <Label htmlFor="status">Status</Label>
                      <Select
                        value={memberForm.watch("status")}
                        onValueChange={(value) => memberForm.setValue("status", value as "active" | "inactive" | "pending")}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="inactive">Inactive</SelectItem>
                          <SelectItem value="pending">Pending</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <Label htmlFor="address">Address</Label>
                      <Textarea
                        id="address"
                        {...memberForm.register("address")}
                        placeholder="Enter complete address"
                      />
                    </div>

                    <div>
                      <Label htmlFor="birthplace">Birthplace</Label>
                      <Input
                        id="birthplace"
                        {...memberForm.register("birthplace")}
                        placeholder="Enter birthplace"
                      />
                    </div>

                    <div>
                      <Label htmlFor="parentsName">Parents Name</Label>
                      <Input
                        id="parentsName"
                        {...memberForm.register("parentsName")}
                        placeholder="Enter parents name"
                      />
                    </div>

                    <div>
                      <Label htmlFor="sourceOfIncome">Source of Income</Label>
                      <Input
                        id="sourceOfIncome"
                        {...memberForm.register("sourceOfIncome")}
                        placeholder="Enter source of income"
                      />
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    disabled={updateMemberMutation.isPending}
                    className="w-full"
                  >
                    {updateMemberMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Update Member Information
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="security" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Password Reset</CardTitle>
                <CardDescription>Reset member's password</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={passwordForm.handleSubmit(onSubmitPassword)} className="space-y-4">
                  <div>
                    <Label htmlFor="newPassword">New Password</Label>
                    <div className="relative">
                      <Input
                        id="newPassword"
                        type={showPassword ? "text" : "password"}
                        {...passwordForm.register("newPassword")}
                        placeholder="Enter new password"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                    {passwordForm.formState.errors.newPassword && (
                      <p className="text-sm text-red-500">{passwordForm.formState.errors.newPassword.message}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="confirmPassword">Confirm Password</Label>
                    <Input
                      id="confirmPassword"
                      type={showPassword ? "text" : "password"}
                      {...passwordForm.register("confirmPassword")}
                      placeholder="Confirm new password"
                    />
                    {passwordForm.formState.errors.confirmPassword && (
                      <p className="text-sm text-red-500">{passwordForm.formState.errors.confirmPassword.message}</p>
                    )}
                  </div>

                  <Button 
                    type="submit" 
                    disabled={resetPasswordMutation.isPending}
                    className="w-full"
                  >
                    {resetPasswordMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Reset Password
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="cbu" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Capital Build-Up (CBU)</CardTitle>
                <CardDescription>Manage member's capital shares</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-muted p-4 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <DollarSign className="h-5 w-5 text-primary" />
                      <div>
                        <p className="text-sm text-muted-foreground">Current CBU Amount</p>
                        <p className="text-2xl font-bold">
                          ₱{capitalShare?.amount ? capitalShare.amount.toLocaleString('en-PH', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                          }) : "0.00"}
                        </p>
                      </div>
                    </div>
                  </div>

                  <form onSubmit={cbuForm.handleSubmit(onSubmitCBU)} className="space-y-4">
                    <div>
                      <Label htmlFor="amount">New CBU Amount</Label>
                      <Input
                        id="amount"
                        type="number"
                        step="0.01"
                        min="0"
                        {...cbuForm.register("amount")}
                        placeholder="Enter new CBU amount"
                      />
                      {cbuForm.formState.errors.amount && (
                        <p className="text-sm text-red-500">{cbuForm.formState.errors.amount.message}</p>
                      )}
                    </div>

                    <Button 
                      type="submit" 
                      disabled={updateCBUMutation.isPending}
                      className="w-full"
                    >
                      {updateCBUMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      Update CBU Amount
                    </Button>
                  </form>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="savings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Member Savings</CardTitle>
                <CardDescription>Manage member's savings account</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-muted p-4 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <DollarSign className="h-5 w-5 text-primary" />
                      <div>
                        <p className="text-sm text-muted-foreground">Current Savings Balance</p>
                        <p className="text-2xl font-bold">
                          ₱{savingsData?.balance ? savingsData.balance.toLocaleString('en-PH', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                          }) : "0.00"}
                        </p>
                      </div>
                    </div>
                  </div>

                  <form onSubmit={savingsForm.handleSubmit(onSubmitSavings)} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="savingsAmount">Amount</Label>
                        <Input
                          id="savingsAmount"
                          type="number"
                          step="0.01"
                          min="0.01"
                          {...savingsForm.register("amount")}
                          placeholder="Enter amount"
                        />
                        {savingsForm.formState.errors.amount && (
                          <p className="text-sm text-red-500">{savingsForm.formState.errors.amount.message}</p>
                        )}
                      </div>

                      <div>
                        <Label htmlFor="transactionType">Transaction Type</Label>
                        <Select
                          value={savingsForm.watch("transactionType")}
                          onValueChange={(value) => savingsForm.setValue("transactionType", value as "deposit" | "withdrawal")}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select transaction type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="deposit">
                              <div className="flex items-center">
                                <Plus className="mr-2 h-4 w-4 text-green-500" />
                                Deposit
                              </div>
                            </SelectItem>
                            <SelectItem value="withdrawal">
                              <div className="flex items-center">
                                <Minus className="mr-2 h-4 w-4 text-red-500" />
                                Withdrawal
                              </div>
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="note">Note (Optional)</Label>
                      <Textarea
                        id="note"
                        {...savingsForm.register("note")}
                        placeholder="Enter transaction note"
                      />
                    </div>

                    <Button 
                      type="submit" 
                      disabled={addSavingsMutation.isPending}
                      className="w-full"
                    >
                      {addSavingsMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      Add Transaction
                    </Button>
                  </form>

                  {savingsData?.transactions && savingsData.transactions.length > 0 && (
                    <div>
                      <h4 className="text-sm font-medium mb-2">Recent Transactions</h4>
                      <div className="border rounded-lg">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Date</TableHead>
                              <TableHead>Type</TableHead>
                              <TableHead>Amount</TableHead>
                              <TableHead>Balance</TableHead>
                              <TableHead>Note</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {savingsData.transactions.slice(0, 5).map((transaction) => (
                              <TableRow key={transaction.id}>
                                <TableCell>
                                  {format(new Date(transaction.date), "MMM d, yyyy")}
                                </TableCell>
                                <TableCell>
                                  <div className={`flex items-center ${
                                    transaction.transactionType === 'deposit' ? 'text-green-600' : 'text-red-600'
                                  }`}>
                                    {transaction.transactionType === 'deposit' ? (
                                      <Plus className="mr-1 h-3 w-3" />
                                    ) : (
                                      <Minus className="mr-1 h-3 w-3" />
                                    )}
                                    {transaction.transactionType}
                                  </div>
                                </TableCell>
                                <TableCell>
                                  ₱{transaction.amount.toLocaleString('en-PH', {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                  })}
                                </TableCell>
                                <TableCell>
                                  ₱{transaction.balance.toLocaleString('en-PH', {
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2
                                  })}
                                </TableCell>
                                <TableCell>{transaction.note || "-"}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}