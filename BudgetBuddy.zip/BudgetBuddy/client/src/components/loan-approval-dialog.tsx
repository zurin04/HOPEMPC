import { useState } from "react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Loader2 } from "lucide-react";
import { Loan, User, CapitalShare } from "@shared/schema";

type LoanApprovalDialogProps = {
  loan: Loan;
  isOpen: boolean;
  onClose: () => void;
};

export function LoanApprovalDialog({ loan, isOpen, onClose }: LoanApprovalDialogProps) {
  const [note, setNote] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch the member details for this loan
  const { data: member, isLoading: isMemberLoading } = useQuery<User>({
    queryKey: [`/api/admin/members/${loan.userId}`],
    enabled: isOpen, // Only fetch when dialog is open
  });
  
  // Fetch capital share information
  const { data: capitalShare, isLoading: isCapitalShareLoading } = useQuery<CapitalShare>({
    queryKey: [`/api/admin/capital-shares/${loan.userId}`],
    enabled: isOpen, // Only fetch when dialog is open
  });

  const approveMutation = useMutation({
    mutationFn: async ({ loanId, action, note }: { loanId: number; action: string; note: string }) => {
      const response = await apiRequest("POST", `/api/admin/loans/${loanId}/approve`, { action, note });
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/loans"] });
      queryClient.invalidateQueries({ queryKey: [`/api/admin/loans/${loan.id}`] });
      // Also invalidate notification queries
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread"] });
      
      toast({
        title: "Success",
        description: "Loan application processed successfully",
      });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to process loan: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleApprove = () => {
    approveMutation.mutate({ loanId: loan.id, action: "approve", note });
  };

  const handleReject = () => {
    approveMutation.mutate({ loanId: loan.id, action: "reject", note });
  };

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString('en-PH', { style: 'currency', currency: 'PHP' });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold flex items-center gap-2">
            <Badge variant={loan.status === "pending" ? "warning" : "outline"} className="uppercase">
              {loan.status}
            </Badge>
            Loan Application Review
          </DialogTitle>
          <DialogDescription>
            Review the loan application details before making a decision.
          </DialogDescription>
        </DialogHeader>

        {(isMemberLoading || isCapitalShareLoading) ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid gap-5 py-4">
            {/* Member Info Card */}
            <Card className="overflow-hidden border-l-4 border-l-primary">
              <CardContent className="p-4">
                <h3 className="text-lg font-semibold mb-2">Member Information</h3>
                {member ? (
                  <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                    <div className="font-medium">Name:</div>
                    <div>{member.name}</div>
                    
                    <div className="font-medium">Member ID:</div>
                    <div>#{member.id}</div>
                    
                    <div className="font-medium">Email:</div>
                    <div>{member.email}</div>
                    
                    <div className="font-medium">Contact Number:</div>
                    <div>{member.contactNumber || "Not provided"}</div>
                    
                    <div className="font-medium">Capital Share:</div>
                    <div className="font-semibold text-primary">
                      {capitalShare ? formatCurrency(capitalShare.amount) : "No capital share"}
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">Member information unavailable</p>
                )}
              </CardContent>
            </Card>

            {/* Loan Details Card */}
            <Card>
              <CardContent className="p-4">
                <h3 className="text-lg font-semibold mb-2">Loan Details</h3>
                <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                  <div className="font-medium">Loan Amount:</div>
                  <div className="font-semibold">{formatCurrency(loan.amount)}</div>
                  
                  <div className="font-medium">Interest Rate:</div>
                  <div>{loan.interest}%</div>
                  
                  <div className="font-medium">Term:</div>
                  <div>{loan.term} months</div>
                  
                  <div className="font-medium">Payment Schedule:</div>
                  <div className="capitalize">{loan.schedule}</div>
                  
                  <div className="font-medium">Start Date:</div>
                  <div>{new Date(loan.startDate).toLocaleDateString()}</div>
                  
                  <div className="font-medium">Monthly Payment:</div>
                  <div>
                    {formatCurrency((loan.amount * (1 + loan.interest/100)) / loan.term)}
                  </div>
                  
                  <div className="font-medium">Total to be Repaid:</div>
                  <div className="font-semibold">
                    {formatCurrency(loan.amount * (1 + loan.interest/100))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* 80% of Capital Share Rule Check */}
            {capitalShare && (
              <div className="rounded-lg bg-gray-50 dark:bg-gray-800 p-4 text-sm">
                <h4 className="font-medium mb-1">Capital Share Rule Check</h4>
                <div className="flex items-center gap-2">
                  <Badge 
                    variant={loan.amount <= capitalShare.amount * 0.8 ? "success" : "destructive"}
                    className="h-6"
                  >
                    {loan.amount <= capitalShare.amount * 0.8 ? "PASSED" : "FAILED"}
                  </Badge>
                  <span>
                    {loan.amount <= capitalShare.amount * 0.8 
                      ? "Loan amount is within 80% of capital share."
                      : "Loan amount exceeds 80% of capital share."}
                  </span>
                </div>
                <div className="mt-1 text-xs text-muted-foreground">
                  Maximum allowed: {formatCurrency(capitalShare.amount * 0.8)}
                </div>
              </div>
            )}

            <Separator />
            
            <div>
              <label htmlFor="note" className="block text-sm font-medium mb-1">
                Add a note (optional):
              </label>
              <Textarea
                id="note"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Add any comments about this loan application"
                rows={3}
              />
            </div>
          </div>
        )}

        <DialogFooter className="flex justify-between gap-2 mt-4">
          <Button
            variant="destructive"
            onClick={handleReject}
            disabled={approveMutation.isPending}
            className="min-w-[120px]"
          >
            {approveMutation.isPending && approveMutation.variables?.action === "reject" ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : null}
            Reject
          </Button>
          <Button
            onClick={handleApprove}
            disabled={approveMutation.isPending}
            className="min-w-[120px]"
          >
            {approveMutation.isPending && approveMutation.variables?.action === "approve" ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : null}
            Approve
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
