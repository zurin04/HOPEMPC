import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { Loader2, ArrowLeft, ChevronDown, DollarSign } from "lucide-react";
import { useLocation, Link } from "wouter";
import MemberLayout from "@/layouts/member-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Loan, Payment } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface LoanWithPayments {
  loan: Loan;
  payments: Payment[];
}

export default function MemberPayments() {
  const [, setLocation] = useLocation();
  const [selectedLoanId, setSelectedLoanId] = useState<number | null>(null);
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const { toast } = useToast();

  // Get loan ID from URL if available
  const urlParams = new URLSearchParams(window.location.search);
  const loanIdParam = urlParams.get("loanId");

  // Fetch loans
  const { data: loans, isLoading: isLoadingLoans } = useQuery<Loan[]>({
    queryKey: ["/api/members/loans"],
    onSuccess: (data) => {
      // If we have a loan ID in the URL and the loans loaded, select that loan
      if (loanIdParam && !selectedLoanId) {
        const loanId = parseInt(loanIdParam);
        const loan = data.find(l => l.id === loanId);
        if (loan && loan.status === "active") {
          setSelectedLoanId(loanId);
          // Calculate default payment (monthly payment amount)
          setPaymentAmount(loan.amount / loan.term);
        }
      }
    }
  });

  // Fetch loan details (including payments) when a loan is selected
  const { data: selectedLoanData, isLoading: isLoadingLoanDetails } = useQuery<LoanWithPayments>({
    queryKey: ["/api/members/loans", selectedLoanId],
    enabled: !!selectedLoanId,
    queryFn: async () => {
      const response = await fetch(`/api/members/loans/${selectedLoanId}`);
      if (!response.ok) throw new Error("Failed to fetch loan details");
      return response.json();
    }
  });

  // Create payment mutation
  const createPaymentMutation = useMutation({
    mutationFn: async ({ loanId, amount }: { loanId: number, amount: number }) => {
      const response = await apiRequest("POST", `/api/members/loans/${loanId}/payments`, {
        amount,
        datePaid: new Date().toISOString()
      });
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Payment Successful",
        description: "Your payment has been processed successfully.",
      });
      // Refresh loan data
      queryClient.invalidateQueries({ queryKey: ["/api/members/loans"] });
      queryClient.invalidateQueries({ queryKey: ["/api/members/loans", selectedLoanId] });
      // Reset payment amount
      setPaymentAmount(0);
    },
    onError: (error) => {
      toast({
        title: "Payment Failed",
        description: error instanceof Error ? error.message : "An error occurred while processing your payment.",
        variant: "destructive",
      });
    }
  });

  // Handle payment submission
  const handlePaymentSubmit = () => {
    if (!selectedLoanId) {
      toast({
        title: "Error",
        description: "Please select a loan to make a payment.",
        variant: "destructive",
      });
      return;
    }

    if (paymentAmount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid payment amount greater than zero.",
        variant: "destructive",
      });
      return;
    }

    createPaymentMutation.mutate({ loanId: selectedLoanId, amount: paymentAmount });
  };

  // Get active loans
  const activeLoans = loans?.filter(loan => loan.status === "active") || [];

  // Calculate monthly payment for a loan
  const calculateMonthlyPayment = (loan: Loan) => {
    const principal = loan.amount;
    const interestRate = loan.interest / 100;
    const numPayments = loan.term;
    
    // Simple calculation (principal + interest) / term
    return (principal * (1 + interestRate)) / numPayments;
  };

  return (
    <MemberLayout>
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => setLocation("/loans")} className="mr-2">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Loans
          </Button>
          <h1 className="text-2xl font-bold">Make a Payment</h1>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Loan selection and payment form */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Payment Details</CardTitle>
            <CardDescription>Select a loan and enter payment amount</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingLoans ? (
              <div className="space-y-4">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            ) : activeLoans.length > 0 ? (
              <div className="space-y-6">
                <div className="space-y-3">
                  <Label>Select Loan to Pay</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {activeLoans.map((loan) => (
                      <div
                        key={loan.id}
                        className={`border rounded-md p-4 cursor-pointer transition-colors ${selectedLoanId === loan.id
                          ? 'border-primary bg-primary/5'
                          : 'border-gray-200 hover:border-gray-300 dark:border-gray-700 dark:hover:border-gray-600'
                          }`}
                        onClick={() => {
                          setSelectedLoanId(loan.id);
                          // Set default payment to monthly payment amount
                          setPaymentAmount(calculateMonthlyPayment(loan));
                        }}
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-medium">Loan #{loan.id}</p>
                            <p className="text-sm text-gray-500 dark:text-gray-400">
                              Balance: ₱{loan.balance.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </p>
                          </div>
                          <div className="h-4 w-4 rounded-full bg-green-500 mt-1" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {selectedLoanId && (
                  <div className="space-y-4">
                    <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-md">
                      <Collapsible>
                        <div className="flex justify-between items-center">
                          <h3 className="text-sm font-medium">Loan Details</h3>
                          <CollapsibleTrigger asChild>
                            <Button variant="ghost" size="sm" className="p-0 h-8 w-8">
                              <ChevronDown className="h-4 w-4" />
                            </Button>
                          </CollapsibleTrigger>
                        </div>

                        <CollapsibleContent>
                          {isLoadingLoanDetails ? (
                            <Skeleton className="h-20 w-full mt-2" />
                          ) : selectedLoanData ? (
                            <div className="mt-2 text-sm space-y-1">
                              <div className="flex justify-between">
                                <span className="text-gray-500 dark:text-gray-400">Loan Amount:</span>
                                <span>₱{selectedLoanData.loan.amount.toLocaleString('en-PH', {
                                  minimumFractionDigits: 2,
                                  maximumFractionDigits: 2
                                })}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-500 dark:text-gray-400">Current Balance:</span>
                                <span>₱{selectedLoanData.loan.balance.toLocaleString('en-PH', {
                                  minimumFractionDigits: 2,
                                  maximumFractionDigits: 2
                                })}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-500 dark:text-gray-400">Interest Rate:</span>
                                <span>{selectedLoanData.loan.interest}%</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-500 dark:text-gray-400">Term:</span>
                                <span>{selectedLoanData.loan.term} months</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-500 dark:text-gray-400">Payment Schedule:</span>
                                <span className="capitalize">{selectedLoanData.loan.schedule}</span>
                              </div>
                              <div className="flex justify-between pt-1 border-t border-gray-200 dark:border-gray-700 mt-1">
                                <span className="text-gray-500 dark:text-gray-400">Payments Made:</span>
                                <span>{selectedLoanData.payments.length}</span>
                              </div>
                            </div>
                          ) : null}
                        </CollapsibleContent>
                      </Collapsible>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="payment-amount">Payment Amount</Label>
                      <div className="flex items-center">
                        <span className="bg-gray-100 dark:bg-gray-800 px-3 py-2 border border-r-0 rounded-l-md border-gray-300 dark:border-gray-600">₱</span>
                        <Input
                          id="payment-amount"
                          type="number"
                          min="0"
                          step="0.01"
                          value={paymentAmount}
                          onChange={(e) => setPaymentAmount(parseFloat(e.target.value) || 0)}
                          className="rounded-l-none"
                        />
                      </div>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        Recommended payment: ₱{selectedLoanData
                          ? calculateMonthlyPayment(selectedLoanData.loan).toLocaleString('en-PH', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                          })
                          : "0.00"}
                      </p>
                    </div>

                    <Button
                      className="w-full mt-4"
                      onClick={handlePaymentSubmit}
                      disabled={createPaymentMutation.isPending || paymentAmount <= 0}
                    >
                      {createPaymentMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Processing Payment...
                        </>
                      ) : (
                        <>Make Payment</>
                      )}
                    </Button>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-8">
                <DollarSign className="mx-auto h-10 w-10 text-gray-400 mb-3" />
                <h3 className="text-lg font-medium mb-1">No Active Loans</h3>
                <p className="text-gray-500 dark:text-gray-400 mb-4">
                  You don't have any active loans to make payments on.
                </p>
                <Link href="/loans">
                  <Button variant="outline">View All Loans</Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Payment History */}
        <Card>
          <CardHeader>
            <CardTitle>Payment History</CardTitle>
            <CardDescription>Recent payments for selected loan</CardDescription>
          </CardHeader>
          <CardContent>
            {selectedLoanId ? (
              isLoadingLoanDetails ? (
                <div className="space-y-4">
                  <Skeleton className="h-8 w-full" />
                  <Skeleton className="h-8 w-full" />
                  <Skeleton className="h-8 w-full" />
                </div>
              ) : selectedLoanData && selectedLoanData.payments.length > 0 ? (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Amount</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedLoanData.payments.map((payment) => (
                        <TableRow key={payment.id}>
                          <TableCell>
                            {format(new Date(payment.datePaid), "MMM d, yyyy")}
                          </TableCell>
                          <TableCell>
                            ₱{payment.amount.toLocaleString('en-PH', {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2
                            })}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                  No payment records found for this loan.
                </div>
              )
            ) : (
              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                Select a loan to view payment history.
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </MemberLayout>
  );
}
