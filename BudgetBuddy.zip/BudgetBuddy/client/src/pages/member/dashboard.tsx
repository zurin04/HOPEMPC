import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { ArrowDown, ArrowUp, CalendarIcon, Coins, HandCoins } from "lucide-react";
import MemberLayout from "@/layouts/member-layout";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Loan, Payment, CapitalShare, NewsFeed } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

interface TransactionWithType extends Payment {
  type: string;
  description: string;
  status: string;
  loanDetails?: Loan;
}

export default function MemberDashboard() {
  const { user } = useAuth();

  // Fetch capital share
  const { data: capitalShare, isLoading: isLoadingCapitalShare } = useQuery<CapitalShare>({
    queryKey: ["/api/members/capital-shares"],
  });

  // Fetch loans
  const { data: loans, isLoading: isLoadingLoans } = useQuery<Loan[]>({
    queryKey: ["/api/members/loans"],
  });

  // Fetch payments
  const { data: payments, isLoading: isLoadingPayments } = useQuery<Payment[]>({
    queryKey: ["/api/members/payments"],
  });

  // Fetch news
  const { data: news, isLoading: isLoadingNews } = useQuery<NewsFeed[]>({
    queryKey: ["/api/news"],
  });

  // Calculate active loan balance (sum of all active loans)
  const activeLoanBalance = loans
    ?.filter(loan => loan.status === "active")
    .reduce((sum, loan) => sum + loan.balance, 0) || 0;

  // Calculate next payment due
  const getNextPaymentDue = () => {
    const activeLoans = loans?.filter(loan => loan.status === "active") || [];
    if (activeLoans.length === 0) return { amount: 0, date: null };

    // For simplicity, we'll take the amount from the first active loan
    // In a real application, you might have a more complex calculation
    const loan = activeLoans[0];
    const monthlyPayment = loan.amount / loan.term;
    
    // Get the next payment date based on schedule
    const nextDate = new Date();
    if (loan.schedule === "monthly") {
      nextDate.setMonth(nextDate.getMonth() + 1);
    } else if (loan.schedule === "weekly") {
      nextDate.setDate(nextDate.getDate() + 7);
    }
    
    return { amount: monthlyPayment, date: nextDate };
  };

  const nextPaymentDue = getNextPaymentDue();

  // Format recent transactions
  const getRecentTransactions = (): TransactionWithType[] => {
    if (!payments || !loans) return [];

    const transactions: TransactionWithType[] = [];

    // Add loan payments
    payments.slice(0, 5).forEach(payment => {
      const relatedLoan = loans.find(loan => loan.id === payment.loanId);
      if (relatedLoan) {
        transactions.push({
          ...payment,
          type: "Payment",
          description: "Loan Payment",
          status: "Completed",
          loanDetails: relatedLoan
        });
      }
    });

    // Add active loans as transactions
    loans
      .filter(loan => loan.status === "active" || loan.status === "approved")
      .slice(0, 3)
      .forEach(loan => {
        transactions.push({
          id: loan.id,
          loanId: loan.id,
          amount: loan.amount,
          datePaid: loan.createdAt,
          type: "Loan",
          description: "New Loan Application",
          status: loan.status === "active" ? "Approved" : "Pending",
          loanDetails: loan
        });
      });

    // Sort by date descending
    return transactions
      .sort((a, b) => new Date(b.datePaid).getTime() - new Date(a.datePaid).getTime())
      .slice(0, 5);
  };

  const recentTransactions = getRecentTransactions();

  return (
    <MemberLayout>
      <h1 className="text-2xl font-bold mb-6">Member Dashboard</h1>
      
      {/* Welcome Card */}
      <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">Welcome Back, {user?.name || "Member"}!</h2>
        <p className="text-gray-600 dark:text-gray-400">
          Your last login was on <span className="font-medium">{format(new Date(), "MMMM d, yyyy 'at' h:mm a")}</span>
        </p>
        
        {isLoadingNews ? (
          <div className="mt-4">
            <h3 className="font-medium mb-2">Recent Updates</h3>
            <Skeleton className="h-16 w-full" />
          </div>
        ) : news && news.length > 0 ? (
          <div className="mt-4">
            <h3 className="font-medium mb-2">Recent Updates</h3>
            <div className="bg-blue-50 dark:bg-blue-900/30 p-3 rounded-md border-l-4 border-blue-500">
              <p className="text-sm text-blue-800 dark:text-blue-200">{news[0].title}</p>
            </div>
          </div>
        ) : (
          <div className="mt-4">
            <h3 className="font-medium mb-2">Recent Updates</h3>
            <div className="bg-gray-100 dark:bg-gray-700 p-3 rounded-md">
              <p className="text-sm text-gray-500 dark:text-gray-400">No recent updates available.</p>
            </div>
          </div>
        )}
      </Card>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {/* Capital Share Card */}
        <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-md">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 dark:text-gray-400 text-sm">Total Capital Share</p>
                {isLoadingCapitalShare ? (
                  <Skeleton className="h-8 w-32 mt-1" />
                ) : (
                  <h3 className="text-2xl font-bold mt-1">
                    ₱{capitalShare?.amount.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || "0.00"}
                  </h3>
                )}
              </div>
              <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-md">
                <Coins className="h-5 w-5 text-green-600 dark:text-green-400" />
              </div>
            </div>
            {!isLoadingCapitalShare && (
              <div className="mt-4 flex items-center text-sm">
                <span className="text-green-500 flex items-center">
                  <ArrowUp className="mr-1 h-3 w-3" /> 12%
                </span>
                <span className="text-gray-500 dark:text-gray-400 ml-2">since last quarter</span>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Active Loan Balance Card */}
        <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-md">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 dark:text-gray-400 text-sm">Active Loan Balance</p>
                {isLoadingLoans ? (
                  <Skeleton className="h-8 w-32 mt-1" />
                ) : (
                  <h3 className="text-2xl font-bold mt-1">
                    ₱{activeLoanBalance.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </h3>
                )}
              </div>
              <div className="p-2 bg-orange-100 dark:bg-orange-900/30 rounded-md">
                <HandCoins className="h-5 w-5 text-orange-600 dark:text-orange-400" />
              </div>
            </div>
            {!isLoadingLoans && (
              <div className="mt-4 flex items-center text-sm">
                <span className="text-red-500 flex items-center">
                  <ArrowDown className="mr-1 h-3 w-3" /> 8%
                </span>
                <span className="text-gray-500 dark:text-gray-400 ml-2">paid this month</span>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Next Payment Due Card */}
        <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-md">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-500 dark:text-gray-400 text-sm">Next Payment Due</p>
                {isLoadingLoans ? (
                  <Skeleton className="h-8 w-32 mt-1" />
                ) : (
                  <h3 className="text-2xl font-bold mt-1">
                    ₱{nextPaymentDue.amount.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </h3>
                )}
              </div>
              <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-md">
                <CalendarIcon className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
            {!isLoadingLoans && (
              <div className="mt-4 flex items-center text-sm">
                <span className="text-gray-500 dark:text-gray-400">Due on</span>
                <span className="text-gray-800 dark:text-gray-200 ml-2 font-medium">
                  {nextPaymentDue.date 
                    ? format(nextPaymentDue.date, "MMMM d, yyyy") 
                    : "No active loans"}
                </span>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Recent Transactions */}
      <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-md mb-6">
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold mb-4">Recent Transactions</h2>
          
          {isLoadingPayments || isLoadingLoans ? (
            <div className="space-y-4">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          ) : recentTransactions.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentTransactions.map((transaction) => (
                    <TableRow key={`${transaction.type}-${transaction.id}`}>
                      <TableCell className="text-gray-500 dark:text-gray-400">
                        {format(new Date(transaction.datePaid), "MMM d, yyyy")}
                      </TableCell>
                      <TableCell>
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          transaction.type === 'Payment' 
                            ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' 
                            : 'bg-purple-100 dark:bg-purple-900 text-purple-800 dark:text-purple-200'
                        }`}>
                          {transaction.type}
                        </span>
                      </TableCell>
                      <TableCell className="text-gray-800 dark:text-gray-200">{transaction.description}</TableCell>
                      <TableCell className="text-gray-800 dark:text-gray-200">
                        ₱{transaction.amount.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell>
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          transaction.status === 'Completed' || transaction.status === 'Approved'
                            ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200'
                            : transaction.status === 'Pending'
                            ? 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                            : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200'
                        }`}>
                          {transaction.status}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              No transactions available.
            </div>
          )}
          
          {!isLoadingPayments && !isLoadingLoans && recentTransactions.length > 0 && (
            <div className="mt-4 text-right">
              <a 
                href="/payments" 
                className="text-primary hover:text-primary/80 dark:text-primary-foreground dark:hover:text-primary-foreground/80 text-sm font-medium"
              >
                View all transactions <ArrowUp className="ml-1 inline-block h-3 w-3 rotate-45" />
              </a>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Latest News */}
      <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-md">
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold mb-4">Latest Cooperative News</h2>
          
          {isLoadingNews ? (
            <div className="space-y-4">
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
            </div>
          ) : news && news.length > 0 ? (
            <div className="space-y-4">
              {news.slice(0, 2).map((item) => (
                <div key={item.id} className="border-l-4 border-primary pl-4 py-2">
                  <h3 className="font-medium text-gray-800 dark:text-gray-200">{item.title}</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    {item.content.length > 100 ? `${item.content.substring(0, 100)}...` : item.content}
                  </p>
                  <div className="mt-2 flex justify-between items-center">
                    <span className="text-xs text-gray-500 dark:text-gray-400">
                      Posted on {format(new Date(item.createdAt), "MMM d, yyyy")}
                    </span>
                    <a 
                      href="/news" 
                      className="text-xs text-primary hover:text-primary/80 dark:text-primary-foreground dark:hover:text-primary-foreground/80 font-medium"
                    >
                      Read more
                    </a>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              No news available.
            </div>
          )}
          
          {!isLoadingNews && news && news.length > 0 && (
            <div className="mt-4 text-right">
              <a 
                href="/news" 
                className="text-primary hover:text-primary/80 dark:text-primary-foreground dark:hover:text-primary-foreground/80 text-sm font-medium"
              >
                View all news <ArrowUp className="ml-1 inline-block h-3 w-3 rotate-45" />
              </a>
            </div>
          )}
        </CardContent>
      </Card>
    </MemberLayout>
  );
}
