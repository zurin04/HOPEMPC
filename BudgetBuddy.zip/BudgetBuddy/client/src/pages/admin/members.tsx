import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { format } from "date-fns";
import { 
  UserPlus, Search, Download, X, RefreshCw, Check, Ban, 
  Trash, User, Loader2, FilterIcon, UserX, AlertCircle, Settings
} from "lucide-react";
import AdminLayout from "@/layouts/admin-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { exportToExcel } from "@/lib/utils/excel";
import { User as UserType } from "@shared/schema";
import { AdminMemberEditDialog } from "@/components/admin-member-edit-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type MemberFilter = "all" | "active" | "inactive";

export default function AdminMembers() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // State management
  const [searchTerm, setSearchTerm] = useState("");
  const [filter, setFilter] = useState<MemberFilter>("all");
  const [selectedMember, setSelectedMember] = useState<UserType | null>(null);
  const [showEditMemberDialog, setShowEditMemberDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  // Data fetching
  const { data: members, isLoading: isLoadingMembers, error: membersError } = useQuery<UserType[]>({
    queryKey: [`/api/admin/members/${filter === "all" ? "" : filter}`],
  });

  // Mutations for member operations
  const deleteMemberMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/admin/members/${id}`, "DELETE");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/admin/members/${filter === "all" ? "" : filter}`] });
      setShowDeleteDialog(false);
      setSelectedMember(null);
      toast({
        title: "Success",
        description: "Member deleted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete member.",
        variant: "destructive",
      });
    },
  });

  const updateMemberMutation = useMutation({
    mutationFn: async ({ id, values }: { id: number; values: { name: string; status: string } }) => {
      return apiRequest(`/api/admin/members/${id}`, "PATCH", values);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/admin/members/${filter === "all" ? "" : filter}`] });
      toast({
        title: "Success",
        description: "Member status updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update member status.",
        variant: "destructive",
      });
    },
  });

  // Handle opening edit dialog
  const handleEditMember = (member: UserType) => {
    setSelectedMember(member);
    setShowEditMemberDialog(true);
  };

  // Handle opening delete dialog
  const handleDeleteMember = (member: UserType) => {
    setSelectedMember(member);
    setShowDeleteDialog(true);
  };

  // Handle delete confirmation
  const confirmDelete = () => {
    if (!selectedMember) return;
    deleteMemberMutation.mutate(selectedMember.id);
  };

  // Filter members based on search term
  const filteredMembers = members?.filter(member => 
    member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (member.email?.toLowerCase().includes(searchTerm.toLowerCase()) ?? false) ||
    member.id.toString().includes(searchTerm)
  );

  // Calculate stats
  const totalMembers = members?.length || 0;
  const activeMembers = members?.filter(m => m.status === "active").length || 0;
  const inactiveMembers = members?.filter(m => m.status === "inactive").length || 0;

  // Export members to Excel
  const handleExport = () => {
    if (!members || members.length === 0) {
      toast({
        title: "Export Failed",
        description: "No members data available to export.",
        variant: "destructive",
      });
      return;
    }
    
    const columns = [
      { key: "id", header: "ID" },
      { key: "name", header: "Name" },
      { key: "email", header: "Email" },
      { key: "status", header: "Status" },
      { key: "role", header: "Role" },
      { key: "createdAt", header: "Created Date" },
    ];
    
    // Format dates before export
    const formattedMembers = members.map(member => ({
      ...member,
      createdAt: format(new Date(member.createdAt), "MMM d, yyyy"),
    }));

    exportToExcel(formattedMembers, {
      filename: "members",
      columns: columns
    });
    
    toast({
      title: "Export Successful",
      description: "Members data has been exported to Excel.",
    });
  };

  return (
    <AdminLayout>
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold">Member Management</h1>
          <p className="text-muted-foreground">Manage cooperative members and their information</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
          <Button asChild className="w-full sm:w-auto">
            <Link href="/admin/member-registration">
              <UserPlus className="mr-2 h-4 w-4" />
              Add Member
            </Link>
          </Button>
          
          <Button 
            variant="outline" 
            onClick={handleExport}
            disabled={!members || members.length === 0}
            className="w-full sm:w-auto"
          >
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-muted-foreground">Total Members</p>
                {isLoadingMembers ? (
                  <Skeleton className="h-8 w-16 mt-1" />
                ) : (
                  <p className="text-2xl font-bold">{totalMembers}</p>
                )}
              </div>
              <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-md">
                <User className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-muted-foreground">Active Members</p>
                {isLoadingMembers ? (
                  <Skeleton className="h-8 w-16 mt-1" />
                ) : (
                  <p className="text-2xl font-bold">{activeMembers}</p>
                )}
              </div>
              <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-md">
                <Check className="h-5 w-5 text-green-600 dark:text-green-400" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-muted-foreground">Inactive Members</p>
                {isLoadingMembers ? (
                  <Skeleton className="h-8 w-16 mt-1" />
                ) : (
                  <p className="text-2xl font-bold">{inactiveMembers}</p>
                )}
              </div>
              <div className="p-2 bg-red-100 dark:bg-red-900/30 rounded-md">
                <Ban className="h-5 w-5 text-red-600 dark:text-red-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Member List */}
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <CardTitle>Member List</CardTitle>
              <CardDescription>Manage cooperative members</CardDescription>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
              <div className="relative w-full sm:w-auto">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  className="pl-8 w-full sm:w-[200px]"
                  placeholder="Search members..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                {searchTerm && (
                  <button
                    onClick={() => setSearchTerm("")}
                    className="absolute right-2.5 top-2.5 text-muted-foreground hover:text-foreground"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
              
              <Select 
                value={filter} 
                onValueChange={(value) => setFilter(value as MemberFilter)}
              >
                <SelectTrigger className="w-full sm:w-[140px]">
                  <FilterIcon className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Filter" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Members</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
              
              <Button 
                variant="outline" 
                size="icon"
                onClick={() => {
                  queryClient.invalidateQueries({ queryKey: [`/api/admin/members/${filter === "all" ? "" : filter}`] });
                }}
                disabled={isLoadingMembers}
              >
                <RefreshCw className={`h-4 w-4 ${isLoadingMembers ? 'animate-spin' : ''}`} />
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          {membersError ? (
            <div className="text-center py-10">
              <AlertCircle className="h-10 w-10 text-red-500 mx-auto mb-3" />
              <h3 className="text-lg font-medium mb-1">Error Loading Members</h3>
              <p className="text-muted-foreground mb-4">
                {membersError instanceof Error ? membersError.message : "Failed to load members"}
              </p>
              <Button 
                variant="outline" 
                onClick={() => queryClient.invalidateQueries({ queryKey: [`/api/admin/members/${filter === "all" ? "" : filter}`] })}
              >
                Try Again
              </Button>
            </div>
          ) : isLoadingMembers ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center space-x-4">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-4 w-[250px]" />
                    <Skeleton className="h-4 w-[200px]" />
                  </div>
                  <Skeleton className="h-8 w-20" />
                </div>
              ))}
            </div>
          ) : filteredMembers && filteredMembers.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[60px]">ID</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead className="w-[200px]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMembers.map((member) => (
                    <TableRow key={member.id}>
                      <TableCell className="font-medium">#{member.id}</TableCell>
                      <TableCell className="font-medium">{member.name}</TableCell>
                      <TableCell>{member.email || "N/A"}</TableCell>
                      <TableCell>
                        <Badge variant={member.status === "active" ? "default" : "secondary"}>
                          {member.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={member.role === "admin" ? "destructive" : "outline"}>
                          {member.role}
                        </Badge>
                      </TableCell>
                      <TableCell>{format(new Date(member.createdAt), "MMM d, yyyy")}</TableCell>
                      <TableCell>
                        <div className="flex space-x-1">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleEditMember(member)}
                            title="Manage Member"
                            className="h-8 px-2"
                          >
                            <Settings className="h-4 w-4 mr-1" />
                            Manage
                          </Button>
                          
                          <Button 
                            variant="ghost" 
                            size="icon"
                            className={member.status === "active" ? "text-red-500" : "text-green-500"}
                            onClick={() => {
                              updateMemberMutation.mutate({
                                id: member.id,
                                values: {
                                  name: member.name,
                                  status: member.status === "active" ? "inactive" : "active",
                                },
                              });
                            }}
                            title={member.status === "active" ? "Deactivate" : "Activate"}
                          >
                            {member.status === "active" ? 
                              <UserX className="h-4 w-4" /> : 
                              <Check className="h-4 w-4" />}
                          </Button>

                          {member.role !== "admin" && (
                            <Button 
                              variant="ghost" 
                              size="icon"
                              className="text-red-500 hover:text-red-700 hover:bg-red-100"
                              onClick={() => handleDeleteMember(member)}
                              title="Delete Member"
                            >
                              <Trash className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-10">
              <UserX className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
              <h3 className="text-lg font-medium mb-1">No Members Found</h3>
              <p className="text-muted-foreground mb-4">
                {searchTerm 
                  ? "No members match your search criteria." 
                  : `No ${filter !== "all" ? filter : ""} members found.`}
              </p>
              {searchTerm && (
                <Button 
                  variant="outline" 
                  onClick={() => setSearchTerm("")}
                >
                  Clear Search
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-red-500" />
              Confirm Deletion
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to delete {selectedMember?.name}? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowDeleteDialog(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={confirmDelete}
              disabled={deleteMemberMutation.isPending}
            >
              {deleteMemberMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Trash className="mr-2 h-4 w-4" />
              )}
              Delete Member
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Comprehensive Member Management Dialog */}
      <AdminMemberEditDialog
        member={selectedMember}
        isOpen={showEditMemberDialog}
        onClose={() => {
          setShowEditMemberDialog(false);
          setSelectedMember(null);
        }}
      />
    </AdminLayout>
  );
}