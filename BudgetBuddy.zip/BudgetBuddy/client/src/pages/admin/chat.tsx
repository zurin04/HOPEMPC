import AdminLayout from "@/layouts/admin-layout";
import { OfficerChat } from "@/components/officer-chat";

export default function AdminChatPage() {
  return (
    <AdminLayout>
      <div className="flex flex-col">
        <h1 className="text-2xl font-bold mb-6">Officers Chat</h1>
        <div className="grid grid-cols-1 gap-4">
          <OfficerChat />
        </div>
      </div>
    </AdminLayout>
  );
}
