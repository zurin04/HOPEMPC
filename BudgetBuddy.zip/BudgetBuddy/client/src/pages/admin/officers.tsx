import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Search, Trash2 } from "lucide-react";

import AdminLayout from "@/layouts/admin-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest } from "@/lib/queryClient";
import { Officer, User } from "@shared/schema";

// Form Schema
const officerSchema = z.object({
  userId: z.coerce.number().positive("Member is required"),
  position: z.string().min(1, "Position is required"),
});

type OfficerFormValues = z.infer<typeof officerSchema>;

interface OfficerWithDetails extends Officer {
  name?: string;
}

export default function AdminOfficers() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showRemoveDialog, setShowRemoveDialog] = useState(false);
  const [selectedOfficer, setSelectedOfficer] = useState<OfficerWithDetails | null>(null);
  
  // Fetch officers
  const { data: officers, isLoading: isLoadingOfficers } = useQuery<OfficerWithDetails[]>({
    queryKey: ["/api/admin/officers"],
  });
  
  // Fetch active members for officer assignment
  const { data: members, isLoading: isLoadingMembers } = useQuery<User[]>({
    queryKey: ["/api/admin/members/active"],
  });
  
  // Add new officer
  const addOfficerMutation = useMutation({
    mutationFn: async (data: OfficerFormValues) => {
      const res = await apiRequest("POST", "/api/admin/officers", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Officer assigned successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/officers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/officer-status"] });
      setShowAddDialog(false);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to assign officer",
        variant: "destructive",
      });
    },
  });
  
  // Remove officer
  const removeOfficerMutation = useMutation({
    mutationFn: async (officerId: number) => {
      await apiRequest("DELETE", `/api/admin/officers/${officerId}`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Officer removed successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/officers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/officer-status"] });
      setShowRemoveDialog(false);
      setSelectedOfficer(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to remove officer",
        variant: "destructive",
      });
    },
  });
  
  // Form
  const form = useForm<OfficerFormValues>({
    resolver: zodResolver(officerSchema),
    defaultValues: {
      userId: undefined,
      position: "",
    },
  });
  
  // Filter officers by search term
  const filteredOfficers = officers?.filter(officer =>
    officer.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    officer.position.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];
  
  // Handlers
  const handleAddSubmit = (data: OfficerFormValues) => {
    addOfficerMutation.mutate(data);
  };
  
  const handleRemoveClick = (officer: OfficerWithDetails) => {
    setSelectedOfficer(officer);
    setShowRemoveDialog(true);
  };
  
  const handleRemoveConfirm = () => {
    if (selectedOfficer) {
      removeOfficerMutation.mutate(selectedOfficer.id);
    }
  };
  
  const positions = [
    "Chairperson",
    "Vice Chairperson",
    "Secretary",
    "Treasurer",
    "Auditor",
    "Board Member",
  ];
  
  return (
    <AdminLayout>
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Officers</h1>
        <Button onClick={() => setShowAddDialog(true)}>
          <Plus className="h-4 w-4 mr-2" /> Assign Officer
        </Button>
      </div>
      
      <div className="my-6">
        <Input
          placeholder="Search officers..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full max-w-sm"
          icon={<Search className="h-4 w-4" />}
        />
      </div>
      
      <Card>
        <CardContent className="pt-6">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Position</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoadingOfficers ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell><Skeleton className="h-6 w-32" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-20" /></TableCell>
                  </TableRow>
                ))
              ) : filteredOfficers.length > 0 ? (
                filteredOfficers.map((officer) => (
                  <TableRow key={officer.id}>
                    <TableCell>{officer.name}</TableCell>
                    <TableCell>{officer.position}</TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveClick(officer)}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={3} className="text-center">
                    No officers found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      {/* Add Officer Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign New Officer</DialogTitle>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleAddSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="userId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Member</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value?.toString()}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a member" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {isLoadingMembers ? (
                          <SelectItem value="loading" disabled>
                            Loading members...
                          </SelectItem>
                        ) : members && members.length > 0 ? (
                          members.map((member) => (
                            <SelectItem key={member.id} value={member.id.toString()}>
                              {member.name}
                            </SelectItem>
                          ))
                        ) : (
                          <SelectItem value="none" disabled>
                            No active members found
                          </SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="position"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Position</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a position" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {positions.map((position) => (
                          <SelectItem key={position} value={position}>
                            {position}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setShowAddDialog(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={addOfficerMutation.isPending}>
                  {addOfficerMutation.isPending ? "Assigning..." : "Assign Officer"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Remove Officer Confirmation */}
      <AlertDialog open={showRemoveDialog} onOpenChange={setShowRemoveDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Officer</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove {selectedOfficer?.name} from the {selectedOfficer?.position} position?
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleRemoveConfirm}
              disabled={removeOfficerMutation.isPending}
            >
              {removeOfficerMutation.isPending ? "Removing..." : "Remove"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AdminLayout>
  );
}
