import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import { ThemeProvider } from "@/components/theme-provider";

// Pages
import AuthPage from "@/pages/auth-page";

// Member pages
import MemberDashboard from "@/pages/member/dashboard";
import MemberProfile from "@/pages/member/profile";
import MemberCapitalShares from "@/pages/member/capital-shares";
import MemberLoans from "@/pages/member/loans";
import MemberPayments from "@/pages/member/payments";
import MemberNews from "@/pages/member/news";

// Admin pages
import AdminDashboard from "@/pages/admin/dashboard";
import AdminMembers from "@/pages/admin/members";
import MemberRegistration from "@/pages/admin/member-registration";
import AdminLoans from "@/pages/admin/loans";
import AdminPayments from "@/pages/admin/payments";
import AdminFunds from "@/pages/admin/funds";
import AdminOfficers from "@/pages/admin/officers";
import AdminIncomeExpenses from "@/pages/admin/income-expenses";
import AdminNewsfeed from "@/pages/admin/newsfeed";
import AdminReports from "@/pages/admin/reports";
import AdminChat from "@/pages/admin/chat";

function Router() {
  return (
    <Switch>
      {/* Auth Route */}
      <Route path="/auth" component={AuthPage} />
      
      {/* Member Routes */}
      <ProtectedRoute path="/" component={MemberDashboard} role="member" />
      <ProtectedRoute path="/profile" component={MemberProfile} role="member" />
      <ProtectedRoute path="/capital-shares" component={MemberCapitalShares} role="member" />
      <ProtectedRoute path="/loans" component={MemberLoans} role="member" />
      <ProtectedRoute path="/payments" component={MemberPayments} role="member" />
      <ProtectedRoute path="/news" component={MemberNews} role="member" />
      
      {/* Admin Routes */}
      <ProtectedRoute path="/admin" component={AdminDashboard} role="admin" />
      <ProtectedRoute path="/admin/members" component={AdminMembers} role="admin" />
      <ProtectedRoute path="/admin/member-registration" component={MemberRegistration} role="admin" />
      <ProtectedRoute path="/admin/loans" component={AdminLoans} role="admin" />
      <ProtectedRoute path="/admin/payments" component={AdminPayments} role="admin" />
      <ProtectedRoute path="/admin/funds" component={AdminFunds} role="admin" />
      <ProtectedRoute path="/admin/officers" component={AdminOfficers} role="admin" />
      <ProtectedRoute path="/admin/income-expenses" component={AdminIncomeExpenses} role="admin" />
      <ProtectedRoute path="/admin/newsfeed" component={AdminNewsfeed} role="admin" />
      <ProtectedRoute path="/admin/reports" component={AdminReports} role="admin" />
      <ProtectedRoute path="/admin/chat" component={AdminChat} role="admin" />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light">
        <AuthProvider>
          <Router />
          <Toaster />
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
