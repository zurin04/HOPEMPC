import { ReactNode, useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useTheme } from "@/components/theme-provider";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Loader2, Moon, Sun, Menu, LayoutDashboard, Users, HandCoins, 
  BanknoteIcon, PiggyBank, UserCog, LineChart, Megaphone, FileText, LogOut,
  MessageSquare
} from "lucide-react";
import { useMobile } from "@/hooks/use-mobile";
import { NotificationMenu } from "@/components/notification-menu";
import { useQuery } from "@tanstack/react-query";
import { Loan } from "@shared/schema";

interface AdminLayoutProps {
  children: ReactNode;
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const { user, logoutMutation } = useAuth();
  const { theme, setTheme } = useTheme();
  const [location] = useLocation();
  const isMobile = useMobile();
  const [sidebarOpen, setSidebarOpen] = useState(!isMobile);
  
  // Query to get pending loan count for the badge
  const { data: loans } = useQuery<Loan[]>({
    queryKey: ["/api/admin/loans"],
    refetchInterval: 30000, // Refetch every 30 seconds
  });
  
  // Calculate pending loans count
  const pendingLoansCount = loans?.filter((loan: Loan) => loan.status === "pending").length || 0;

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const navItems = [
    { path: "/admin", label: "Dashboard", icon: <LayoutDashboard className="mr-3 h-5 w-5" /> },
    { path: "/admin/members", label: "Members", icon: <Users className="mr-3 h-5 w-5" /> },
    { 
      path: "/admin/loans", 
      label: "Loans", 
      icon: <HandCoins className="mr-3 h-5 w-5" />,
      badge: pendingLoansCount > 0 ? (
        <Badge className="ml-auto bg-yellow-500 dark:bg-yellow-600">{pendingLoansCount}</Badge>
      ) : null
    },
    { path: "/admin/payments", label: "Payments", icon: <BanknoteIcon className="mr-3 h-5 w-5" /> },
    { path: "/admin/funds", label: "Cooperative Funds", icon: <PiggyBank className="mr-3 h-5 w-5" /> },
    { path: "/admin/officers", label: "Officers", icon: <UserCog className="mr-3 h-5 w-5" /> },
    { path: "/admin/income-expenses", label: "Income & Expenses", icon: <LineChart className="mr-3 h-5 w-5" /> },
    { path: "/admin/newsfeed", label: "News & Updates", icon: <Megaphone className="mr-3 h-5 w-5" /> },
    { path: "/admin/reports", label: "Reports", icon: <FileText className="mr-3 h-5 w-5" /> },
    { path: "/admin/chat", label: "Officer Chat", icon: <MessageSquare className="mr-3 h-5 w-5" /> },
  ];

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900">
      {/* Mobile menu button */}
      <div className="fixed bottom-4 right-4 md:hidden z-20">
        <Button 
          onClick={toggleSidebar} 
          size="icon" 
          className="rounded-full bg-primary"
        >
          <Menu className="h-5 w-5" />
        </Button>
      </div>

      {/* Sidebar */}
      <div 
        className={`fixed inset-y-0 left-0 z-10 w-64 bg-sidebar flex flex-col transition-transform duration-300 transform ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } md:translate-x-0`}
      >
        <div className="p-4 border-b border-sidebar-border">
          <h2 className="text-xl font-bold text-sidebar-foreground">HOPEMPC</h2>
          <p className="text-sm text-sidebar-foreground/70">Admin Portal</p>
        </div>
        
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {navItems.map((item) => (
            <Link
              key={item.path}
              href={item.path}
              className={`sidebar-link ${location === item.path ? 'active' : ''}`}
            >
              {item.icon}
              <span>{item.label}</span>
              {'badge' in item && item.badge}
            </Link>
          ))}
        </nav>
        
        <div className="p-4 border-t border-sidebar-border">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-sidebar-foreground">{user.name}</p>
              <p className="text-sm text-sidebar-foreground/70">Admin ID: #{user.id}</p>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleTheme} 
              className="rounded-full text-sidebar-foreground hover:bg-sidebar-primary"
            >
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
          </div>
          <Button 
            onClick={handleLogout} 
            className="mt-4 w-full bg-sidebar-primary hover:bg-sidebar-primary/80 flex items-center justify-center"
            disabled={logoutMutation.isPending}
          >
            {logoutMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <LogOut className="mr-2 h-4 w-4" />
            )}
            <span>Logout</span>
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 md:ml-64 overflow-auto">
        <div className="p-4 flex justify-end items-center border-b dark:border-gray-800">
          <NotificationMenu />
        </div>
        <div className="p-6">
          {children}
        </div>
      </main>
    </div>
  );
}
