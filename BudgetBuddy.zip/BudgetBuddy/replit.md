# HOPEMPC Cooperative Management System

## Overview

HOPEMPC is a comprehensive web-based cooperative management system designed for the HOPEMPC Cooperative. It provides powerful tools for financial tracking, loan management, member engagement, and administrative operations. The system is optimized for VPS deployment with a one-click setup script for easy installation and management.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with Vite for fast development and building
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and theming support
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation
- **Type Safety**: TypeScript throughout the application

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Authentication**: Passport.js with local strategy and session-based auth
- **Session Storage**: PostgreSQL-backed session store using connect-pg-simple
- **Real-time Communication**: WebSocket server for officer chat functionality
- **API Design**: RESTful API with role-based access control

### Database Schema
- **Users**: Member and admin profiles with detailed personal information
- **Capital Shares**: Member equity tracking with historical updates
- **Loans**: Loan applications, approvals, and balance tracking
- **Payments**: Payment records with verification workflow
- **Funds**: Cooperative fund management (cash, capital, reserves)
- **Officers**: Officer assignments and role management
- **News Feed**: Announcements and news management
- **Financial Records**: Monthly income and expense tracking
- **Notifications**: System notifications for users
- **Member Savings**: Savings account management
- **Dividends**: Dividend distribution records

## Key Components

### Member Portal
- **Dashboard**: Financial overview with recent transactions and loan status
- **Profile Management**: Personal information updates and account settings
- **Capital Shares**: CBU tracking and loan eligibility calculation
- **Loan Management**: Application submission and status monitoring
- **Payment Interface**: Payment submission and history tracking
- **News Access**: Cooperative announcements and updates

### Admin Portal
- **Administrative Dashboard**: System metrics and overview
- **Member Management**: Registration, activation, and profile management
- **Loan Processing**: Application review, approval workflow, and monitoring
- **Payment Verification**: Payment validation and processing
- **Fund Management**: Capital, reserve, and cash flow management
- **Officer Management**: Role assignments and permissions
- **Financial Reporting**: Income, expense, and financial statement generation
- **News Management**: Content creation and publication
- **Real-time Chat**: Officer communication system

### VPS Deployment Features
- **One-Click Setup**: Automated deployment script for Ubuntu VPS
- **Production Ready**: PM2 process management with Nginx reverse proxy
- **Database Management**: PostgreSQL setup with automatic backups
- **SSL Support**: Easy SSL certificate integration with Let's Encrypt
- **Security Focused**: Firewall configuration and secure defaults

## Data Flow

### Authentication Flow
1. User submits credentials via login form
2. Passport.js validates against database using scrypt password hashing
3. Session created and stored in PostgreSQL
4. Role-based routing determines user interface (member/admin)

### Loan Application Flow
1. Member submits loan application with required details
2. System validates against capital share limits and eligibility
3. Admin receives notification for review
4. Approval/rejection workflow with notes and documentation
5. Approved loans generate payment schedules and notifications

### Payment Processing Flow
1. Member submits payment through interface or counter
2. Payment record created with pending status
3. Admin verification workflow with approval controls
4. Verified payments update loan balances and generate receipts
5. Real-time balance updates across all interfaces

## External Dependencies

### Production Dependencies
- **Database**: PostgreSQL 15+ for data persistence
- **Node.js**: v20+ runtime environment
- **Authentication**: Passport.js ecosystem
- **UI Components**: Radix UI primitive components
- **Validation**: Zod schema validation
- **Date Handling**: date-fns for consistent date operations
- **Real-time**: WebSocket for live communications

### Development Dependencies
- **Build Tools**: Vite for development server and building
- **TypeScript**: Type checking and development experience
- **ESBuild**: Fast JavaScript bundling for production
- **Drizzle Kit**: Database migration and schema management

### VPS Deployment Dependencies
- **Ubuntu 20.04+**: Recommended VPS operating system
- **PM2**: Process management for production
- **Nginx**: Reverse proxy and web server
- **Let's Encrypt**: SSL certificate automation

## Deployment Strategy

### VPS Production Deployment
- **Target**: Ubuntu VPS with 2GB+ RAM
- **Build Process**: Vite builds client, ESBuild bundles server
- **Environment**: Production NODE_ENV with secure session secrets
- **Database**: Self-hosted PostgreSQL with automated backups
- **Web Server**: Nginx reverse proxy with SSL support
- **Process Management**: PM2 with automatic restart and monitoring
- **Security**: Firewall configuration and secure defaults

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string
- **SESSION_SECRET**: Secure session encryption key
- **NODE_ENV**: Environment flag for production optimizations

## Changelog

- June 26, 2025: Initial setup
- June 26, 2025: Fixed database connection issues by switching from Neon to PostgreSQL
- June 26, 2025: Removed Windows installation files and guides
- June 26, 2025: Added one-click VPS deployment script with PM2 and Nginx configuration
- June 26, 2025: Created simplified database seeding for production deployment
- June 26, 2025: Updated architecture to focus on VPS deployment with security best practices
- June 26, 2025: Created enhanced deployment script (deploy-simple.sh) with improved error handling
- June 26, 2025: Added comprehensive troubleshooting guide for VPS deployment issues
- June 26, 2025: Fixed PostgreSQL permission issues and PM2 configuration problems
- June 26, 2025: Application successfully running with proper database setup and authentication
- June 26, 2025: Consolidated into single deployment script (deploy.sh) with complete automation
- June 26, 2025: Added management utilities, security features, and production monitoring

## User Preferences

Preferred communication style: Simple, everyday language.