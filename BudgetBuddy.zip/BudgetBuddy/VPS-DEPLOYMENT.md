# HOPEMPC VPS Deployment Guide

## Quick One-Click Deployment

### Prerequisites
- Ubuntu 20.04+ VPS with at least 2GB RAM
- Root or sudo access
- Domain name (optional)

### One-Click Deployment

```bash
# Download and run the comprehensive deployment script
wget https://raw.githubusercontent.com/your-repo/hopempc/main/deploy.sh
chmod +x deploy.sh
./deploy.sh
```

This unified script provides:
- Complete system setup and package installation
- PostgreSQL database with enhanced security permissions
- Node.js application build and configuration
- PM2 process management with logging
- Nginx reverse proxy with security headers
- Automated backup system and firewall setup
- Management utilities and monitoring tools

### Step 2: Access Your Application

After successful deployment:
- Visit: `http://your-server-ip`
- Admin Login: `admin@hopempc.org` / `admin123`
- Member Login: `member@hopempc.org` / `member123`

**Important**: Change default passwords immediately after first login.

## What the Script Does

1. **System Setup**
   - Updates Ubuntu packages
   - Installs Node.js 20.x
   - Installs PostgreSQL database
   - Installs Nginx web server
   - Installs PM2 process manager

2. **Application Setup**
   - Creates application directory
   - Installs dependencies
   - Sets up database with schema
   - Seeds initial data
   - Builds production version

3. **Production Configuration**
   - Configures Nginx reverse proxy
   - Sets up PM2 for process management
   - Configures automatic backups
   - Enables system services

## Post-Deployment Steps

### 1. Security Configuration
```bash
# Change default passwords in the admin panel
# Set up firewall
sudo ufw allow 22
sudo ufw allow 80
sudo ufw allow 443
sudo ufw enable
```

### 2. SSL Certificate (Recommended)
```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Get SSL certificate (replace with your domain)
sudo certbot --nginx -d yourdomain.com
```

### 3. Domain Configuration
Edit `/etc/nginx/sites-available/hopempc` and replace `server_name _;` with your domain.

## Management Commands

### Application Management
```bash
# View application status
pm2 status

# View logs
pm2 logs hopempc

# Restart application
pm2 restart hopempc

# Stop application
pm2 stop hopempc
```

### Database Management
```bash
# Connect to database
psql -h localhost -U hopempc_user hopempc_db

# Manual backup
./backup.sh

# View backups
ls -la /var/backups/hopempc/
```

## Troubleshooting

For detailed troubleshooting steps, see [TROUBLESHOOTING.md](./TROUBLESHOOTING.md)

### Quick Fixes

1. **Database permission errors**:
```bash
sudo -u postgres psql -d hopempc_db -c "GRANT ALL ON SCHEMA public TO hopempc_user;"
```

2. **PM2 configuration issues**:
```bash
mv ecosystem.config.js ecosystem.config.cjs
pm2 start ecosystem.config.cjs
```

3. **Environment variable issues**:
```bash
export DATABASE_URL=postgresql://hopempc_user:hopempc_secure_password@localhost:5432/hopempc_db
```

4. **Application not starting**:
```bash
pm2 logs hopempc
pm2 restart hopempc
```

### Service Status
```bash
# Check all services
sudo systemctl status nginx postgresql
pm2 status
```

### Complete Reset (if needed)
```bash
# Stop services and redeploy
pm2 delete all
sudo rm -rf /var/www/hopempc
./deploy-simple.sh
```

## Backup and Recovery

### Automatic Backups
- Daily backups at 2 AM
- Database and application files
- 7-day retention policy
- Location: `/var/backups/hopempc/`

### Manual Backup
```bash
# Run backup script
./backup.sh

# Restore database from backup
psql -h localhost -U hopempc_user hopempc_db < /var/backups/hopempc/backup_file.sql
```

## Updating Application

```bash
# Pull latest changes
git pull origin main

# Install new dependencies
npm install

# Run database migrations
npm run db:push

# Rebuild application
npm run build

# Restart application
pm2 restart hopempc
```

## Support

For technical support or questions:
- Check logs: `pm2 logs hopempc`
- Review this guide
- Contact system administrator

---

**Note**: This deployment creates a production-ready setup with proper process management, automatic backups, and security configurations. Always test on a staging environment before deploying to production.