#!/bin/bash

# HOPEMPC One-Click VPS Deployment Script
# Complete production-ready deployment for Ubuntu VPS

set -e  # Exit on any error

echo "======================================"
echo "HOPEMPC One-Click VPS Deployment"
echo "======================================"

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   print_error "Do not run as root. Use a regular user with sudo privileges."
   exit 1
fi

# Check if sudo is available
if ! command -v sudo &> /dev/null; then
    print_error "sudo is required but not installed."
    exit 1
fi

# Update system packages
print_status "Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install essential packages
print_status "Installing essential packages..."
sudo apt install -y curl wget gnupg lsb-release software-properties-common apt-transport-https ca-certificates

# Install Node.js 20.x
print_status "Installing Node.js 20.x..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
else
    print_warning "Node.js already installed: $(node --version)"
fi

# Install PostgreSQL
print_status "Installing PostgreSQL..."
if ! command -v psql &> /dev/null; then
    sudo apt install -y postgresql postgresql-contrib
    sudo systemctl start postgresql
    sudo systemctl enable postgresql
else
    print_warning "PostgreSQL already installed"
    sudo systemctl start postgresql
fi

# Install Nginx
print_status "Installing Nginx..."
if ! command -v nginx &> /dev/null; then
    sudo apt install -y nginx
    sudo systemctl start nginx
    sudo systemctl enable nginx
else
    print_warning "Nginx already installed"
    sudo systemctl start nginx
fi

# Install PM2 globally
print_status "Installing PM2 process manager..."
if ! command -v pm2 &> /dev/null; then
    sudo npm install -g pm2
else
    print_warning "PM2 already installed"
fi

# Create application directory
APP_DIR="/var/www/hopempc"
print_status "Setting up application directory at $APP_DIR..."
sudo mkdir -p $APP_DIR
sudo chown $USER:$USER $APP_DIR

# Copy application files
print_status "Copying application files..."
cp -r . $APP_DIR/
cd $APP_DIR

# Install Node.js dependencies
print_status "Installing Node.js dependencies..."
npm install

# Generate secure password for database
DB_PASSWORD=$(openssl rand -base64 32)
SESSION_SECRET=$(openssl rand -hex 32)

# Setup PostgreSQL database with proper permissions
print_status "Setting up PostgreSQL database..."

# Remove existing database and user if they exist
sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS hopempc_db;
DROP USER IF EXISTS hopempc_user;
EOF

# Create new database and user with all permissions
sudo -u postgres psql << EOF
CREATE DATABASE hopempc_db;
CREATE USER hopempc_user WITH ENCRYPTED PASSWORD '$DB_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE hopempc_db TO hopempc_user;
ALTER USER hopempc_user CREATEDB;
ALTER USER hopempc_user WITH SUPERUSER;
\q
EOF

# Grant schema permissions
sudo -u postgres psql -d hopempc_db << EOF
GRANT ALL ON SCHEMA public TO hopempc_user;
GRANT CREATE ON SCHEMA public TO hopempc_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO hopempc_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO hopempc_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON FUNCTIONS TO hopempc_user;
\q
EOF

print_status "Database setup completed"

# Create environment configuration
print_status "Creating environment configuration..."
DATABASE_URL_VALUE="postgresql://hopempc_user:$DB_PASSWORD@localhost:5432/hopempc_db"

cat > .env << EOF
DATABASE_URL=$DATABASE_URL_VALUE
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=3000
EOF

# Set environment variables for current session
export DATABASE_URL="$DATABASE_URL_VALUE"
export SESSION_SECRET="$SESSION_SECRET"
export NODE_ENV=production
export PORT=3000

# Source the .env file to ensure variables are available
set -a
source .env
set +a

# Test database connection
print_status "Testing database connection..."
if sudo -u postgres psql -d hopempc_db -c "SELECT version();" > /dev/null; then
    print_status "Database connection successful"
else
    print_error "Database connection failed"
    exit 1
fi

# Setup database schema
print_status "Setting up database schema..."
if DATABASE_URL="$DATABASE_URL_VALUE" npm run db:push; then
    print_status "Database schema created successfully"
else
    print_error "Failed to create database schema"
    exit 1
fi

# Seed database with initial data
print_status "Seeding database with initial data..."
if DATABASE_URL="$DATABASE_URL_VALUE" npx tsx db/simple-seed.ts; then
    print_status "Database seeded successfully"
else
    print_error "Failed to seed database"
    exit 1
fi

# Fix any password issues
print_status "Verifying password integrity..."
if DATABASE_URL="$DATABASE_URL_VALUE" npx tsx db/fix-passwords.ts; then
    print_status "Password verification completed"
else
    print_warning "Password verification had issues but continuing..."
fi

# Build application for production
print_status "Building application for production..."
if npm run build; then
    print_status "Application built successfully"
else
    print_error "Failed to build application"
    exit 1
fi

# Create PM2 ecosystem configuration
print_status "Creating PM2 configuration..."
cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: 'hopempc',
    script: './dist/index.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 3000,
      DATABASE_URL: 'postgresql://hopempc_user:$DB_PASSWORD@localhost:5432/hopempc_db',
      SESSION_SECRET: '$SESSION_SECRET'
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true
  }]
}
EOF

# Create logs directory
mkdir -p logs

# Configure Nginx with enhanced settings
print_status "Configuring Nginx..."
sudo tee /etc/nginx/sites-available/hopempc > /dev/null << EOF
server {
    listen 80;
    server_name _;
    
    client_max_body_size 100M;
    client_body_timeout 120s;
    client_header_timeout 120s;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
        proxy_send_timeout 300s;
    }
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
}
EOF

# Enable Nginx site and remove default
sudo ln -sf /etc/nginx/sites-available/hopempc /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test Nginx configuration
if sudo nginx -t; then
    sudo systemctl reload nginx
    print_status "Nginx configured successfully"
else
    print_error "Nginx configuration failed"
    exit 1
fi

# Stop any existing PM2 processes
pm2 delete all 2>/dev/null || true

# Start application with PM2
print_status "Starting application with PM2..."
if pm2 start ecosystem.config.cjs; then
    print_status "Application started successfully"
else
    print_error "Failed to start application"
    exit 1
fi

# Save PM2 configuration
pm2 save

# Setup PM2 startup script
print_status "Setting up PM2 startup script..."
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME

# Create comprehensive backup script
print_status "Creating backup script..."
cat > backup.sh << EOF
#!/bin/bash
BACKUP_DIR="/var/backups/hopempc"
DATE=\$(date +%Y%m%d_%H%M%S)
mkdir -p \$BACKUP_DIR

# Backup database
PGPASSWORD=$DB_PASSWORD pg_dump -h localhost -U hopempc_user hopempc_db > \$BACKUP_DIR/hopempc_db_\$DATE.sql

# Backup application files
tar -czf \$BACKUP_DIR/hopempc_app_\$DATE.tar.gz -C /var/www hopempc --exclude=node_modules --exclude=dist

# Keep only last 7 days of backups
find \$BACKUP_DIR -name "*.sql" -mtime +7 -delete
find \$BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete

echo "Backup completed: \$DATE"
EOF

chmod +x backup.sh

# Setup automatic backups
print_status "Setting up automatic backups..."
(crontab -l 2>/dev/null | grep -v "hopempc"; echo "0 2 * * * $APP_DIR/backup.sh") | crontab -

# Configure firewall
print_status "Configuring firewall..."
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw --force enable

# Create management script
print_status "Creating management script..."
cat > manage.sh << 'EOF'
#!/bin/bash

case "$1" in
    start)
        pm2 start ecosystem.config.cjs
        ;;
    stop)
        pm2 stop hopempc
        ;;
    restart)
        pm2 restart hopempc
        ;;
    status)
        pm2 status
        pm2 logs hopempc --lines 20
        ;;
    logs)
        pm2 logs hopempc
        ;;
    backup)
        ./backup.sh
        ;;
    update)
        git pull
        npm install
        npm run build
        pm2 restart hopempc
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status|logs|backup|update}"
        exit 1
        ;;
esac
EOF

chmod +x manage.sh

# Get server IP
SERVER_IP=$(curl -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')

# Final status check
print_status "Performing final status check..."
sleep 5

if pm2 list | grep -q "hopempc.*online"; then
    DEPLOYMENT_STATUS="SUCCESS"
else
    DEPLOYMENT_STATUS="WARNING - Application may need manual restart"
fi

# Save deployment info
cat > deployment-info.txt << EOF
HOPEMPC Deployment Information
=============================
Date: $(date)
Server IP: $SERVER_IP
Database User: hopempc_user
Database Password: $DB_PASSWORD
Session Secret: $SESSION_SECRET

Admin Credentials:
- Email: admin@hopempc.org
- Password: admin123

Member Credentials:
- Email: member@hopempc.org
- Password: member123

Management Commands:
- ./manage.sh status    # Check application status
- ./manage.sh restart   # Restart application
- ./manage.sh logs      # View logs
- ./manage.sh backup    # Manual backup
- ./manage.sh update    # Update application

Service Management:
- sudo systemctl status nginx postgresql
- pm2 status
- pm2 logs hopempc

File Locations:
- Application: $APP_DIR
- Backups: /var/backups/hopempc
- Logs: $APP_DIR/logs
- Config: $APP_DIR/.env

IMPORTANT: Change default passwords immediately after first login!
EOF

echo ""
echo "======================================"
echo "DEPLOYMENT COMPLETED!"
echo "======================================"
echo ""
print_status "Application URL: http://$SERVER_IP"
print_status "Admin Login: admin@hopempc.org / admin123"
print_status "Member Login: member@hopempc.org / member123"
echo ""
print_status "Deployment Status: $DEPLOYMENT_STATUS"
echo ""
print_status "Management Commands:"
echo "  ./manage.sh status    # Check application status"
echo "  ./manage.sh restart   # Restart application"
echo "  ./manage.sh logs      # View application logs"
echo "  ./manage.sh backup    # Create manual backup"
echo ""
print_status "Security Setup:"
echo "  - Firewall configured (ports 22, 80, 443)"
echo "  - Automatic backups scheduled (daily 2 AM)"
echo "  - PM2 process management enabled"
echo "  - Nginx reverse proxy configured"
echo ""
print_warning "IMPORTANT NEXT STEPS:"
echo "  1. Change default passwords immediately"
echo "  2. Configure your domain name if available"
echo "  3. Set up SSL certificate: sudo certbot --nginx"
echo "  4. Review deployment-info.txt for credentials"
echo ""
print_status "Deployment information saved to: deployment-info.txt"
echo "======================================"